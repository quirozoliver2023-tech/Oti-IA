package com.azmovil.otiplus;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class FilePickerActivity extends Activity {
    private static final int PICK = 700;
    private String mode;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); mode = getIntent().getStringExtra("mode");
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData(); FileWorkspace.saveLastDocument(this,u);
            if ("share_whatsapp".equals(mode)) FileWorkspace.share(this,u,"com.whatsapp");
            else FileWorkspace.open(this,u);
        }
        finish();
    }
}
