package com.azmovil.otiplus;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Locale;
import java.util.Queue;
import java.util.Set;

public final class FileWorkspace {
    private static final String KEY_TREE = "workspace_tree";
    private static final String KEY_LAST = "last_document";
    private FileWorkspace() {}

    public static void saveTree(Context c, Uri uri) {
        if (uri == null) return;
        try {
            c.getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) {}
        Prefs.get(c).edit().putString(KEY_TREE, uri.toString()).apply();
    }

    public static Uri tree(Context c) {
        String s = Prefs.get(c).getString(KEY_TREE, null);
        return s == null ? null : Uri.parse(s);
    }

    public static void saveLastDocument(Context c, Uri uri) {
        if (uri == null) return;
        try { c.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) {}
        Prefs.get(c).edit().putString(KEY_LAST, uri.toString()).apply();
    }

    public static Uri lastDocument(Context c) {
        String s = Prefs.get(c).getString(KEY_LAST, null);
        return s == null ? null : Uri.parse(s);
    }

    public static boolean createFolder(Context c, String name) {
        Uri tree = tree(c);
        if (tree == null || name == null || name.trim().isEmpty()) return false;
        try {
            String rootId = DocumentsContract.getTreeDocumentId(tree);
            Uri root = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
            return DocumentsContract.createDocument(c.getContentResolver(), root,
                    DocumentsContract.Document.MIME_TYPE_DIR, name.trim()) != null;
        } catch (Exception e) { return false; }
    }

    public static Uri findFirst(Context c, String query) {
        Uri tree = tree(c);
        if (tree == null || query == null || query.trim().isEmpty()) return null;
        String q = query.toLowerCase(Locale.ROOT).trim();
        try {
            String rootId = DocumentsContract.getTreeDocumentId(tree);
            Uri root = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
            Queue<Uri> dirs = new ArrayDeque<>();
            Set<String> seen = new HashSet<>();
            dirs.add(root);
            int scanned = 0;
            while (!dirs.isEmpty() && scanned < 500) {
                Uri dir = dirs.poll();
                String did = DocumentsContract.getDocumentId(dir);
                if (!seen.add(did)) continue;
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, did);
                Cursor cur = null;
                try {
                    cur = c.getContentResolver().query(children,
                            new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                                    DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
                    if (cur == null) continue;
                    while (cur.moveToNext() && scanned++ < 500) {
                        String id = cur.getString(0);
                        String name = cur.getString(1);
                        String mime = cur.getString(2);
                        Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, id);
                        if (name != null && name.toLowerCase(Locale.ROOT).contains(q)) return doc;
                        if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) dirs.add(doc);
                    }
                } finally { if (cur != null) cur.close(); }
            }
        } catch (Exception ignored) {}
        return null;
    }

    public static String displayName(Context c, Uri uri) {
        if (uri == null) return "archivo";
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Exception ignored) {} finally { if (cur != null) cur.close(); }
        return "archivo";
    }

    public static boolean open(Context c, Uri uri) {
        if (uri == null) return false;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            c.startActivity(i); return true;
        } catch (Exception e) { return false; }
    }

    public static boolean share(Context c, Uri uri, String packageName) {
        if (uri == null) return false;
        try {
            String mime = c.getContentResolver().getType(uri);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime == null ? "*/*" : mime);
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            if (packageName != null) i.setPackage(packageName);
            c.startActivity(i); return true;
        } catch (Exception e) { return false; }
    }
}
