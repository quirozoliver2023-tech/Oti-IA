package com.azmovil.otiplus;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.content.Intent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class VoiceEnrollmentActivity extends Activity {
    private TextView status;
    private Button sampleButton;
    private SpeechRecognizer recognizer;
    private ByteArrayOutputStream audio;
    private final List<float[]> samples = new ArrayList<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(36,36,36,36);
        TextView title = new TextView(this); title.setText("Mi voz · Oti IA Plus"); title.setTextSize(26); l.addView(title);
        status = new TextView(this); status.setText("Graba 3 muestras diciendo: “Oti, esta es mi voz”. El perfil se guarda localmente y no guarda la grabación completa."); status.setTextSize(17); status.setPadding(0,24,0,24); l.addView(status);
        sampleButton = new Button(this); sampleButton.setText("Grabar muestra 1 de 3"); sampleButton.setOnClickListener(v -> startSample()); l.addView(sampleButton);
        Button clear = new Button(this); clear.setText("Borrar perfil de voz"); clear.setOnClickListener(v -> { VoiceProfileManager.clear(this); samples.clear(); status.setText("Perfil de voz borrado."); sampleButton.setText("Grabar muestra 1 de 3"); }); l.addView(clear);
        setContentView(l);
    }

    private void startSample() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 44); return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.setText("Este teléfono no tiene un motor de reconocimiento disponible."); return; }
        if (recognizer != null) try { recognizer.destroy(); } catch (Exception ignored) {}
        audio = new ByteArrayOutputStream();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { status.setText("Di ahora: Oti, esta es mi voz"); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) { if (buffer != null && audio.size() < 300000) audio.write(buffer,0,buffer.length); }
            @Override public void onEndOfSpeech() {}
            @Override public void onError(int error) { status.setText("No pude capturar la muestra. Intenta de nuevo."); }
            @Override public void onResults(Bundle results) {
                float[] f = VoiceFingerprint.extract(audio.toByteArray());
                if (f == null) {
                    status.setText("El motor de voz de este teléfono no entregó suficiente audio para crear la huella. Puedes usar Oti sin bloqueo por voz y mantener biometría/PIN para acciones sensibles."); return;
                }
                samples.add(f);
                if (samples.size() >= 3) {
                    VoiceProfileManager.save(VoiceEnrollmentActivity.this, VoiceFingerprint.average(samples));
                    Prefs.setVoiceLock(VoiceEnrollmentActivity.this, true);
                    status.setText("Perfil creado. Oti podrá comparar tu voz cuando el motor de reconocimiento entregue audio. Para operaciones sensibles seguirá usando huella/PIN.");
                    sampleButton.setText("Perfil de voz listo"); sampleButton.setEnabled(false);
                } else {
                    status.setText("Muestra " + samples.size() + " guardada. Repite la misma frase.");
                    sampleButton.setText("Grabar muestra " + (samples.size()+1) + " de 3");
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        recognizer.startListening(i);
    }

    @Override protected void onDestroy() { if (recognizer != null) try { recognizer.destroy(); } catch(Exception ignored){} super.onDestroy(); }
}
