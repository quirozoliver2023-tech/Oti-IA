OTI IA 0.4 - ORDENES NATURALES

Esta versión amplía el entendimiento de voz sin exigir frases exactas.

Ejemplos:
- Oti, pon YouTube
- Oti, quiero abrir WhatsApp
- Oti, búscame música en YouTube
- Oti, busca restaurantes en Google
- Oti, llévame al centro
- Oti, ponlo más fuerte
- Oti, baja el volumen
- Oti, abre la cámara
- Oti, marca al 5551234567
- Oti, manda por WhatsApp que voy en camino

Seguridad:
- Las llamadas se preparan en el marcador y el usuario confirma.
- WhatsApp se abre con el texto preparado; el usuario elige destinatario y confirma.
- No lee contraseñas ni realiza pagos.
- No activa Accesibilidad ni lectura de notificaciones en esta versión.

Nota: el reconocimiento de voz convierte voz a texto. El entendimiento de esta versión es local por reglas y sin servidor de IA. Para conversación totalmente libre se puede añadir después un modelo de IA mediante un servicio/API con autorización del usuario.
