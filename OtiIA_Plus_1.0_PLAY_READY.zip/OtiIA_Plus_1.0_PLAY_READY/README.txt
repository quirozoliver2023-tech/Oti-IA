OTI IA PLUS 1.0 PROFESSIONAL
============================

Proyecto Android integrado para convertir Oti en un asistente personal del teléfono, usando únicamente permisos que el dueño concede desde Android.

INCLUIDO EN 1.0
- “Oti” siempre atenta mientras el modo de escucha esté activo, aun fuera de la pantalla de la app.
- Servicio de micrófono en primer plano con notificación visible y botón DETENER OTI.
- Preferencia por reconocimiento de voz local/on-device cuando el teléfono lo ofrece.
- Conversación continua: después de decir “Oti”, acepta frases de seguimiento durante unos segundos sin repetir el nombre.
- Interrupción de la respuesta hablada cuando el usuario vuelve a hablar.
- Perfil de voz local experimental: 3 muestras, huella acústica local y comparación antes de ejecutar órdenes cuando el usuario activa “solo mi voz”. No se conserva el audio de las muestras.
- Confirmación con biometría/PIN del sistema para borrados sensibles de memoria e historial.
- Lenguaje natural para las principales acciones, sin exigir una frase exacta.
- Accesibilidad autorizada: Inicio, Atrás, Recientes, tocar controles visibles, escribir en un campo enfocado, desplazar, leer texto visible y localizar mensajes de error.
- WhatsApp: abrir chat por contacto, preparar/enviar texto cuando Accesibilidad está autorizada, intentar llamada/videollamada mediante la interfaz visible y compartir la última grabación.
- Llamadas normales por contacto o número: abre el marcador y, si se habilita automatización por Accesibilidad, intenta confirmar el botón Llamar.
- Contactos por nombre mediante READ_CONTACTS, solicitado solo cuando el usuario lo autoriza.
- Grabadora visible: graba a Music/Oti IA Plus y muestra notificación permanente con botón DETENER GRABACIÓN.
- Linterna por CameraManager sin abrir la cámara.
- Cámara y grabación de video mediante la app de cámara del sistema.
- Wi-Fi, Bluetooth y Ajustes mediante las pantallas permitidas por Android.
- No molestar mediante acceso especial de política de notificaciones.
- Alarmas mediante la app de reloj del sistema.
- Notificaciones: leer las recientes y responder cuando la notificación expone RemoteInput.
- Archivos: el dueño elige una carpeta con Storage Access Framework; Oti puede buscar dentro de esa carpeta, abrir archivos, crear carpetas y compartir el último documento autorizado.
- Memoria personal local: “recuerda que X es Y” y consulta posterior.
- Rutinas locales: “cuando diga X: acción 1 y luego acción 2”.
- Historial local de acciones.
- IA local para comandos conocidos y IA en nube opcional para preguntas abiertas.
- Configuración opcional de OpenAI Responses API; la clave se guarda cifrada con Android Keystore.
- Botón y acción DETENER OTI.

SEGURIDAD Y PRIVACIDAD
- Oti no oculta el uso del micrófono ni una grabación.
- Oti no roba ni almacena contraseñas.
- Oti no automatiza transferencias, CVV, PIN bancario ni compras con tarjeta.
- Los accesos de Accesibilidad, notificaciones, contactos, archivos y micrófono se conceden desde Android y se pueden revocar.
- El perfil acústico de voz es una personalización experimental, NO una biometría de seguridad certificada. Por eso las acciones sensibles deben usar la biometría/PIN del sistema.

LIMITACIONES REALES DE ANDROID / APPS DE TERCEROS
- “Siempre atenta” usa un servicio de micrófono en primer plano. Android muestra el indicador/notificación de micrófono. Si el usuario fuerza el cierre de Oti, reinicia el teléfono o el sistema detiene el servicio, puede ser necesario abrir Oti y reactivar el modo.
- El motor SpeechRecognizer no garantiza entregar buffers de audio en todos los teléfonos. Si no los entrega, la función “solo mi voz” no se puede calibrar en ese dispositivo; Oti sigue funcionando sin ese bloqueo y usa huella/PIN para acciones sensibles.
- WhatsApp no ofrece una API pública para todas las acciones de llamada, videollamada y envío. Oti las intenta mediante enlaces oficiales y Accesibilidad sobre controles visibles; una actualización de WhatsApp puede requerir ajustar los nombres de los botones.
- Mientras Oti está grabando audio, el micrófono está ocupado. Por fiabilidad, la grabación se detiene desde la notificación “DETENER GRABACIÓN”; en algunos teléfonos una orden de voz para detener puede no oírse durante la grabación.
- El modo de escucha continua consume más batería que un detector de palabra clave dedicado de hardware. Oti prefiere reconocimiento local cuando existe, pero una app normal no obtiene el mismo DSP privado que un asistente preinstalado del fabricante.
- El acceso a archivos se limita a la carpeta que el usuario elija y a documentos que seleccione explícitamente.

EJEMPLOS
- Oti, abre YouTube.
- Oti, dile a Juan por WhatsApp que llego en veinte minutos.
- Oti, llama a Juan por WhatsApp.
- Oti, videollamada a mamá por WhatsApp.
- Oti, llama a mamá.
- Oti, empieza a grabar audio.
- Oti, prende la linterna.
- Oti, ¿quién me escribió?
- Oti, responde a Juan que voy en camino.
- Oti, ¿qué hay en pantalla?
- Oti, ¿qué error aparece?
- Oti, recuerda que el router de la tienda es el principal.
- Oti, ¿qué recuerdas del router de la tienda?
- Oti, cuando diga modo tienda: sube el volumen y luego abre WhatsApp.
- Oti, modo tienda.
- Oti, crea carpeta recibos.
- Oti, busca factura agosto.

COMPILACIÓN
compileSdk 35 / targetSdk 35 / minSdk 26
AGP 8.7.3 / Gradle 8.9 / Java 17
