package com.azmovil.oti;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public class OtiNotificationService extends NotificationListenerService {
    private static final Deque<String> latest = new ArrayDeque<>();
    private static final int MAX = 12;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        CharSequence title = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = n.extras.getCharSequence(Notification.EXTRA_TEXT);

        StringBuilder line = new StringBuilder();
        if (title != null) line.append(title);
        if (text != null && text.length() > 0) {
            if (line.length() > 0) line.append(": ");
            line.append(text);
        }

        String clean = line.toString().trim();
        if (!clean.isEmpty()) {
            synchronized (latest) {
                latest.addFirst(clean);
                while (latest.size() > MAX) latest.removeLast();
            }
        }
    }

    public static List<String> getLatest(int count) {
        List<String> out = new ArrayList<>();
        synchronized (latest) {
            int i = 0;
            for (String s : latest) {
                out.add(s);
                if (++i >= count) break;
            }
        }
        return out;
    }
}
