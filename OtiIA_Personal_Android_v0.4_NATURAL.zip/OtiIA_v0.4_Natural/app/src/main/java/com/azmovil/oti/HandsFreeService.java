package com.azmovil.oti;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.Locale;

public class HandsFreeService extends Service {
    public static final String ACTION_STOP = "com.azmovil.oti.STOP";
    private static final String CHANNEL = "oti_handsfree";
    private static final int NOTIFICATION_ID = 11;

    private SpeechRecognizer recognizer;
    private OtiSpeaker speaker;
    private VoiceCommandProcessor processor;
    private Handler handler;
    private boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        speaker = new OtiSpeaker(this);
        processor = new VoiceCommandProcessor(this, speaker);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopListeningAndSelf();
            return START_NOT_STICKY;
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildNotification());
        if (!running) {
            running = true;
            startRecognizer();
        }
        return START_STICKY;
    }

    private void startRecognizer() {
        if (!running || !SpeechRecognizer.isRecognitionAvailable(this)) return;

        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) {}
        }

        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}

            @Override public void onError(int error) {
                restartSoon(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200 : 550);
            }

            @Override public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) {
                    String heard = list.get(0).trim();
                    String n = heard.toLowerCase(Locale.ROOT);
                    if (n.equals("oti") || n.startsWith("oti ")) {
                        processor.execute(heard);
                    }
                }
                restartSoon(350);
            }

            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);

        try { recognizer.startListening(i); }
        catch (Exception e) { restartSoon(1000); }
    }

    private void restartSoon(long delayMs) {
        if (!running) return;
        handler.removeCallbacksAndMessages(null);
        handler.postDelayed(this::startRecognizer, delayMs);
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, HandsFreeService.class);
        stop.setAction(ACTION_STOP);

        PendingIntent stopPi = PendingIntent.getService(
                this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 2, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);

        return b.setContentTitle("Oti IA está escuchando")
                .setContentText("Di “Oti” seguido de tu orden")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_media_pause, "Detener", stopPi)
                .setOngoing(true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "Oti IA manos libres", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Muestra cuándo Oti IA está usando el micrófono.");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private void cleanup() {
        running = false;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    private void stopListeningAndSelf() {
        cleanup();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        cleanup();
        if (speaker != null) speaker.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
