package com.azmovil.otiplus;

import android.content.Context;
import org.json.JSONObject;
import java.util.Iterator;
import java.util.Locale;

public final class RoutineManager {
    private static final String KEY = "routines_json";
    private RoutineManager() {}
    private static JSONObject load(Context c) {
        try { return new JSONObject(Prefs.get(c).getString(KEY, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    public static synchronized void save(Context c, String trigger, String actions) {
        try {
            JSONObject o = load(c);
            o.put(norm(trigger), actions.trim());
            Prefs.get(c).edit().putString(KEY, o.toString()).apply();
        } catch (Exception ignored) {}
    }
    public static synchronized String find(Context c, String phrase) {
        JSONObject o = load(c);
        String p = norm(phrase);
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String k = it.next();
            if (p.equals(k) || p.endsWith(k)) return o.optString(k, null);
        }
        return null;
    }
    public static synchronized String summary(Context c) {
        JSONObject o = load(c);
        Iterator<String> it = o.keys();
        StringBuilder b = new StringBuilder();
        while (it.hasNext()) {
            String k = it.next();
            if (b.length() > 0) b.append("; ");
            b.append(k).append(" = ").append(o.optString(k));
        }
        return b.length() == 0 ? "No tienes rutinas guardadas." : b.toString();
    }
    public static void clear(Context c) { Prefs.get(c).edit().remove(KEY).apply(); }
    private static String norm(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", " "); }
}
