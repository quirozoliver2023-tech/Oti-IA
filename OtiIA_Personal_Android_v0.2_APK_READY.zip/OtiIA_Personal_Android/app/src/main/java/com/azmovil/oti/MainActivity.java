package com.azmovil.oti;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private TextView statusText;
    private EditText commandInput;
    private SpeechRecognizer recognizer;
    private OtiSpeaker speaker;
    private VoiceCommandProcessor processor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        commandInput = findViewById(R.id.commandInput);

        speaker = new OtiSpeaker(this);
        processor = new VoiceCommandProcessor(this, speaker);

        requestNeededPermissions();

        findViewById(R.id.speakButton).setOnClickListener(v -> listenOnce());

        findViewById(R.id.runCommandButton).setOnClickListener(v -> {
            String cmd = commandInput.getText().toString().trim();
            if (!cmd.isEmpty()) {
                statusText.setText("Orden: " + cmd);
                processor.execute(cmd);
            }
        });

        findViewById(R.id.accessibilityButton).setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        findViewById(R.id.notificationsButton).setOnClickListener(v ->
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));

        findViewById(R.id.startHandsFreeButton).setOnClickListener(v -> {
            Intent i = new Intent(this, HandsFreeService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
            statusText.setText("Manos libres activo. Di: “Oti, ...”");
        });

        findViewById(R.id.stopHandsFreeButton).setOnClickListener(v -> {
            stopService(new Intent(this, HandsFreeService.class));
            statusText.setText("Manos libres detenido.");
        });
    }

    private void requestNeededPermissions() {
        ArrayList<String> perms = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            perms.add(Manifest.permission.RECORD_AUDIO);
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
            perms.add(Manifest.permission.CALL_PHONE);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            perms.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            perms.add(Manifest.permission.POST_NOTIFICATIONS);

        if (!perms.isEmpty()) requestPermissions(perms.toArray(new String[0]), 100);
    }

    private void listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.setText("El reconocimiento de voz no está disponible.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions();
            return;
        }

        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);

        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { statusText.setText("Escuchando..."); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { statusText.setText("Procesando..."); }
            @Override public void onError(int error) { statusText.setText("No entendí. Intenta otra vez."); }
            @Override public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) {
                    String cmd = list.get(0);
                    statusText.setText("Escuché: " + cmd);
                    processor.execute(cmd);
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        recognizer.startListening(i);
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (speaker != null) speaker.shutdown();
        super.onDestroy();
    }
}
