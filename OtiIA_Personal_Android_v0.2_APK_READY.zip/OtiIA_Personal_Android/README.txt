OTI IA PERSONAL - versión 0.1

Esta versión está pensada para instalarse solamente en tu propio Android.

FUNCIONES:
- Reconocimiento de voz en español de México.
- Modo manos libres con la palabra "Oti".
- Abrir WhatsApp, YouTube, Facebook, Chrome, Spotify y TikTok.
- Abrir cámara y Ajustes.
- Inicio, Atrás y Recientes.
- Tocar un botón visible por texto: "Oti, toca Enviar".
- Escribir en un campo activo: "Oti, escribe hola cómo estás".
- Subir/bajar volumen.
- Prender/apagar linterna.
- Leer las últimas notificaciones si tú das permiso.
- Llamar a un número si tú das permiso.

SEGURIDAD:
- No tiene acceso remoto.
- No se oculta.
- No captura contraseñas.
- No envía tus datos a un servidor propio.
- Android muestra cuándo usa el micrófono.
- Pagos, contraseñas y seguridad NO se automatizan.

IMPORTANTE:
Android no permite a una app normal controlar absolutamente todo sin permisos.
También puede limitar el micrófono en segundo plano, especialmente con el teléfono
bloqueado. Esta versión funciona como prototipo privado y se puede ampliar.

PARA COMPILAR:
1. Instala Android Studio en una computadora.
2. Abre la carpeta OtiIA_Personal_Android.
3. Deja que Android Studio sincronice Gradle.
4. Build > Build APK(s).
5. Copia el APK a tu Android e instálalo.
6. Dentro de Oti IA activa:
   - Micrófono
   - Control de pantalla / Accesibilidad
   - Acceso a notificaciones
   - Cámara y llamadas si deseas esas funciones

Este paquete contiene el proyecto fuente y un flujo automático de GitHub Actions:
.github/workflows/build-apk.yml

Si el proyecto se sube a GitHub, el flujo instala Java/Android SDK/Gradle, compila
app-debug.apk y lo deja como artefacto descargable del workflow.

En el entorno actual no está disponible Android SDK/Gradle ni descarga directa de
esas herramientas, por lo que no se puede producir aquí el APK binario.
