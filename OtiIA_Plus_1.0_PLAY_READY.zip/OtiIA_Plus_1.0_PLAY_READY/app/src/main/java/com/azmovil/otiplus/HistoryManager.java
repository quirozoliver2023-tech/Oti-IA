package com.azmovil.otiplus;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class HistoryManager {
    private static final String KEY = "history_json";
    private HistoryManager() {}

    public static synchronized void log(Context c, String action) {
        try {
            JSONArray old = new JSONArray(Prefs.get(c).getString(KEY, "[]"));
            JSONArray out = new JSONArray();
            JSONObject e = new JSONObject();
            e.put("time", System.currentTimeMillis());
            e.put("action", action == null ? "" : action);
            out.put(e);
            for (int i = 0; i < old.length() && i < 99; i++) out.put(old.getJSONObject(i));
            Prefs.get(c).edit().putString(KEY, out.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static synchronized String text(Context c, int max) {
        StringBuilder b = new StringBuilder();
        try {
            JSONArray a = new JSONArray(Prefs.get(c).getString(KEY, "[]"));
            SimpleDateFormat f = new SimpleDateFormat("dd/MM HH:mm", new Locale("es", "MX"));
            for (int i = 0; i < a.length() && i < max; i++) {
                JSONObject e = a.getJSONObject(i);
                b.append(f.format(new Date(e.optLong("time")))).append(" — ")
                        .append(e.optString("action")).append('\n');
            }
        } catch (Exception ignored) {}
        return b.length() == 0 ? "El historial está vacío." : b.toString().trim();
    }

    public static void clear(Context c) { Prefs.get(c).edit().remove(KEY).apply(); }
}
