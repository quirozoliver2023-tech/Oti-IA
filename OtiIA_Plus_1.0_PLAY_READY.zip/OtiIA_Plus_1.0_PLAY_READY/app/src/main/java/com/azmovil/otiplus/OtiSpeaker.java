package com.azmovil.otiplus;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class OtiSpeaker {
    private TextToSpeech tts;
    private boolean ready = false;
    public OtiSpeaker(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                tts.setLanguage(new Locale("es", "MX"));
                tts.setSpeechRate(1.02f); ready = true;
            }
        });
    }
    public void speak(String text) {
        if (ready && tts != null && text != null && !text.isEmpty()) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "oti-plus");
    }
    public void stop() { if (tts != null) try { tts.stop(); } catch(Exception ignored){} }
    public void shutdown() { if (tts != null) { tts.stop(); tts.shutdown(); tts = null; } ready = false; }
}
