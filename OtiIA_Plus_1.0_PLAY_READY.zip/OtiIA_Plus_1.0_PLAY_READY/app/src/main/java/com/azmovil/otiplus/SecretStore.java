package com.azmovil.otiplus;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class SecretStore {
    private static final String ALIAS = "oti_plus_secret";
    private SecretStore() {}

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }

    public static void put(Context c, String name, String value) {
        try {
            Cipher cp = Cipher.getInstance("AES/GCM/NoPadding"); cp.init(Cipher.ENCRYPT_MODE, key());
            byte[] enc = cp.doFinal(value.getBytes(StandardCharsets.UTF_8));
            String packed = Base64.encodeToString(cp.getIV(), Base64.NO_WRAP) + "." + Base64.encodeToString(enc, Base64.NO_WRAP);
            Prefs.get(c).edit().putString("secret_" + name, packed).apply();
        } catch (Exception ignored) {}
    }

    public static String get(Context c, String name) {
        try {
            String packed = Prefs.get(c).getString("secret_" + name, null); if (packed == null) return null;
            String[] p = packed.split("\\.", 2); if (p.length != 2) return null;
            byte[] iv = Base64.decode(p[0], Base64.NO_WRAP); byte[] enc = Base64.decode(p[1], Base64.NO_WRAP);
            Cipher cp = Cipher.getInstance("AES/GCM/NoPadding"); cp.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(cp.doFinal(enc), StandardCharsets.UTF_8);
        } catch (Exception e) { return null; }
    }
    public static void clear(Context c, String name) { Prefs.get(c).edit().remove("secret_" + name).apply(); }
}
