package com.azmovil.otiplus;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import java.text.Normalizer;
import java.util.Locale;

public final class ContactHelper {
    private ContactHelper() {}
    public static String findPhone(Context c, String name) {
        if (name == null) return null;
        String digits = name.replaceAll("[^0-9+]", "");
        if (digits.replace("+", "").length() >= 7) return digits;
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null;
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER},
                    null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (cur == null) return null;
            String q = norm(name);
            String fallback = null;
            while (cur.moveToNext()) {
                String display = cur.getString(0);
                String phone = cur.getString(1);
                String d = norm(display);
                if (d.equals(q)) return clean(phone);
                if (fallback == null && d.contains(q)) fallback = clean(phone);
            }
            return fallback;
        } catch (Exception e) { return null; }
        finally { if (cur != null) cur.close(); }
    }
    private static String clean(String s) { return s == null ? null : s.replaceAll("[^0-9+]", ""); }
    private static String norm(String s) {
        String n = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.trim().replaceAll("\\s+", " ");
    }
}
