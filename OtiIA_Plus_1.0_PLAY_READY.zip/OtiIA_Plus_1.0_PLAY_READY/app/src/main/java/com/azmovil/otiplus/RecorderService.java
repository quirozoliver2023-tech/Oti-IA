package com.azmovil.otiplus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    public static final String ACTION_START = "com.azmovil.otiplus.REC_START";
    public static final String ACTION_STOP = "com.azmovil.otiplus.REC_STOP";
    private static final String CHANNEL = "oti_recorder";
    private static final int ID = 222;
    private MediaRecorder recorder;
    private Uri outputUri;
    private android.os.ParcelFileDescriptor pfd;
    private boolean recording;

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(a)) { stopRecording(); return START_NOT_STICKY; }
        if (!recording) startRecording();
        return START_NOT_STICKY;
    }

    private void startRecording() {
        try {
            startForeground(ID, notification());
            Intent pause = new Intent(this, HandsFreeService.class).setAction(HandsFreeService.ACTION_PAUSE_FOR_RECORDING);
            startService(pause);

            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String name = "Oti_" + stamp + ".m4a";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Audio.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
                v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/Oti IA Plus");
                v.put(MediaStore.Audio.Media.IS_PENDING, 1);
                outputUri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
                if (outputUri == null) throw new IllegalStateException("No output Uri");
                pfd = getContentResolver().openFileDescriptor(outputUri, "w");
            }

            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            if (Build.VERSION.SDK_INT >= 29 && pfd != null) {
                recorder.setOutputFile(pfd.getFileDescriptor());
            } else {
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "Oti IA Plus");
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                File f = new File(dir, name);
                recorder.setOutputFile(f.getAbsolutePath());
                Prefs.get(this).edit().putString("last_recording_path", f.getAbsolutePath()).apply();
            }
            recorder.prepare(); recorder.start(); recording = true;
            HistoryManager.log(this, "Empezó una grabación de audio");
        } catch (Exception e) {
            recording = false; cleanupRecorder(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
            Intent resume = new Intent(this, HandsFreeService.class).setAction(HandsFreeService.ACTION_RESUME_AFTER_RECORDING);
            try { startService(resume); } catch (Exception ignored) {}
        }
    }

    private void stopRecording() {
        if (recording && recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) {}
        }
        recording = false;
        cleanupRecorder();
        if (Build.VERSION.SDK_INT >= 29 && outputUri != null) {
            try {
                ContentValues v = new ContentValues(); v.put(MediaStore.Audio.Media.IS_PENDING, 0);
                getContentResolver().update(outputUri, v, null, null);
                Prefs.get(this).edit().putString("last_recording_uri", outputUri.toString()).apply();
            } catch (Exception ignored) {}
        }
        HistoryManager.log(this, "Terminó y guardó una grabación de audio");
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
        Intent resume = new Intent(this, HandsFreeService.class).setAction(HandsFreeService.ACTION_RESUME_AFTER_RECORDING);
        try { startService(resume); } catch (Exception ignored) {}
    }

    private void cleanupRecorder() {
        if (recorder != null) { try { recorder.reset(); } catch(Exception ignored){} try { recorder.release(); } catch(Exception ignored){} recorder = null; }
        if (pfd != null) { try { pfd.close(); } catch(Exception ignored){} pfd = null; }
    }

    private Notification notification() {
        Intent stop = new Intent(this, RecorderService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 9, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Oti IA Plus está grabando audio")
                .setContentText("Toca DETENER para terminar y guardar")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .addAction(android.R.drawable.ic_media_pause, "DETENER GRABACIÓN", pi)
                .setOngoing(true).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Grabaciones de Oti", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible mientras Oti IA Plus graba audio.");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() { if (recording) stopRecording(); else cleanupRecorder(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }

    public static Uri lastRecordingUri(android.content.Context c) {
        String s = Prefs.get(c).getString("last_recording_uri", null);
        return s == null ? null : Uri.parse(s);
    }
}
