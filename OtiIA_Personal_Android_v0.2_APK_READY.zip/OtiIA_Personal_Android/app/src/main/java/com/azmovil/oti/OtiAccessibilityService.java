package com.azmovil.oti;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class OtiAccessibilityService extends AccessibilityService {
    private static OtiAccessibilityService instance;

    @Override
    protected void onServiceConnected() {
        instance = this;
        super.onServiceConnected();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean global(int action) {
        return instance != null && instance.performGlobalAction(action);
    }

    public static boolean clickText(String text) {
        if (instance == null || text == null || text.trim().isEmpty()) return false;
        AccessibilityNodeInfo root = instance.getRootInActiveWindow();
        if (root == null) return false;

        List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
        if (nodes == null) return false;

        for (AccessibilityNodeInfo node : nodes) {
            AccessibilityNodeInfo target = node;
            while (target != null) {
                if (target.isClickable()) {
                    return target.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                }
                target = target.getParent();
            }
        }
        return false;
    }

    public static boolean typeText(String text) {
        if (instance == null || text == null) return false;
        AccessibilityNodeInfo root = instance.getRootInActiveWindow();
        if (root == null) return false;

        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused == null || !focused.isEditable()) return false;

        Bundle args = new Bundle();
        args.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
        );
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }
}
