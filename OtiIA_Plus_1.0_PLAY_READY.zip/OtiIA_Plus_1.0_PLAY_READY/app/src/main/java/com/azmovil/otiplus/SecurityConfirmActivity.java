package com.azmovil.otiplus;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Intent;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.widget.TextView;

public class SecurityConfirmActivity extends Activity {
    private static final int REQ_DEVICE = 501;
    private String action;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        action = getIntent().getStringExtra("action");
        String d = getIntent().getStringExtra("description");
        TextView t = new TextView(this); t.setPadding(40,60,40,40); t.setTextSize(20); t.setText("Confirmación de seguridad\n\n" + (d == null ? "Acción sensible" : d)); setContentView(t);
        authenticate();
    }
    private void authenticate() {
        if (Build.VERSION.SDK_INT >= 28) {
            BiometricPrompt.Builder b = new BiometricPrompt.Builder(this).setTitle("Confirma que eres tú").setSubtitle("Oti IA Plus");
            if (Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
            else b.setDeviceCredentialAllowed(true);
            BiometricPrompt p = b.build();
            p.authenticate(new CancellationSignal(), getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) { executeConfirmed(); }
                @Override public void onAuthenticationError(int errorCode, CharSequence errString) { if (errorCode != BiometricPrompt.BIOMETRIC_ERROR_CANCELED) finish(); }
            });
        } else {
            KeyguardManager km = (KeyguardManager)getSystemService(KEYGUARD_SERVICE);
            Intent i = km.createConfirmDeviceCredentialIntent("Confirma que eres tú", "Oti IA Plus");
            if (i != null) startActivityForResult(i, REQ_DEVICE); else finish();
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == REQ_DEVICE && resultCode == RESULT_OK) executeConfirmed(); else finish();
    }
    private void executeConfirmed() {
        if ("CLEAR_HISTORY".equals(action)) { HistoryManager.clear(this); HistoryManager.log(this,"Historial reiniciado por el usuario"); }
        else if ("CLEAR_MEMORY".equals(action)) { MemoryManager.clear(this); RoutineManager.clear(this); HistoryManager.log(this,"Memoria y rutinas borradas por el usuario"); }
        else if (action != null && action.startsWith("OPEN_APP:")) {
            String pkg = action.substring("OPEN_APP:".length());
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg); if (i != null) startActivity(i);
        }
        finish();
    }
}
