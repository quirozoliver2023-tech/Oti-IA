package com.azmovil.otiplus;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String NAME = "oti_plus";
    private Prefs() {}
    public static SharedPreferences get(Context c) { return c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }
    public static boolean autoActions(Context c) { return get(c).getBoolean("auto_actions", false); }
    public static boolean voiceLock(Context c) { return get(c).getBoolean("voice_lock", false); }
    public static void setAutoActions(Context c, boolean v) { get(c).edit().putBoolean("auto_actions", v).apply(); }
    public static void setVoiceLock(Context c, boolean v) { get(c).edit().putBoolean("voice_lock", v).apply(); }
}
