package com.azmovil.otiplus;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class HistoryActivity extends Activity {
    private TextView text;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(30,30,30,30);
        TextView t = new TextView(this); t.setText("Historial de Oti IA Plus"); t.setTextSize(25); l.addView(t);
        text = new TextView(this); text.setText(HistoryManager.text(this,100)); text.setTextSize(16); text.setPadding(0,20,0,20); l.addView(text);
        Button clear = new Button(this); clear.setText("Borrar historial con confirmación"); clear.setOnClickListener(v -> {
            android.content.Intent i = new android.content.Intent(this, SecurityConfirmActivity.class);
            i.putExtra("action","CLEAR_HISTORY"); i.putExtra("description","Borrar todo el historial de Oti IA Plus"); startActivity(i);
        }); l.addView(clear);
        ScrollView s = new ScrollView(this); s.addView(l); setContentView(s);
    }
    @Override protected void onResume() { super.onResume(); if (text != null) text.setText(HistoryManager.text(this,100)); }
}
