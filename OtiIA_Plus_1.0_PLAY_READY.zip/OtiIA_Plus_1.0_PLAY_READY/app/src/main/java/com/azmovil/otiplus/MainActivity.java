package com.azmovil.otiplus;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 101;
    private static final int REQ_NOTIFICATIONS = 102;
    private static final int REQ_CONTACTS = 103;
    private static final int REQ_TREE = 104;
    private static final int REQ_DOC = 105;
    private TextView statusText;
    private EditText commandInput;
    private CheckBox autoActions, voiceLock;
    private SpeechRecognizer recognizer;
    private OtiSpeaker speaker;
    private VoiceCommandProcessor processor;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        statusText = findViewById(R.id.statusText);
        commandInput = findViewById(R.id.commandInput);
        autoActions = findViewById(R.id.autoActionsCheck);
        voiceLock = findViewById(R.id.voiceLockCheck);
        autoActions.setChecked(Prefs.autoActions(this));
        voiceLock.setChecked(Prefs.voiceLock(this));
        speaker = new OtiSpeaker(this);
        processor = new VoiceCommandProcessor(this, speaker);

        autoActions.setOnCheckedChangeListener((b,v) -> Prefs.setAutoActions(this,v));
        voiceLock.setOnCheckedChangeListener((b,v) -> {
            if (v && !VoiceProfileManager.enrolled(this)) {
                b.setChecked(false); statusText.setText("Primero crea tu perfil de voz.");
                startActivity(new Intent(this, VoiceEnrollmentActivity.class));
            } else Prefs.setVoiceLock(this,v);
        });

        findViewById(R.id.speakButton).setOnClickListener(v -> ensureMicThenListen());
        findViewById(R.id.runCommandButton).setOnClickListener(v -> runTyped());
        findViewById(R.id.startHandsFreeButton).setOnClickListener(v -> ensurePermissionsThenStartHandsFree());
        findViewById(R.id.stopHandsFreeButton).setOnClickListener(v -> {
            Intent i = new Intent(this, HandsFreeService.class).setAction(HandsFreeService.ACTION_STOP);
            startService(i); statusText.setText("Oti dejó de escuchar.");
        });
        findViewById(R.id.accessibilityButton).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        findViewById(R.id.notificationsButton).setOnClickListener(v -> startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        findViewById(R.id.contactsButton).setOnClickListener(v -> ensureContacts());
        findViewById(R.id.voiceProfileButton).setOnClickListener(v -> startActivity(new Intent(this, VoiceEnrollmentActivity.class)));
        findViewById(R.id.cloudButton).setOnClickListener(v -> startActivity(new Intent(this, CloudSettingsActivity.class)));
        findViewById(R.id.historyButton).setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        findViewById(R.id.workspaceButton).setOnClickListener(v -> chooseWorkspace());
        findViewById(R.id.dndButton).setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));
    }

    private void runTyped() {
        String cmd = commandInput.getText().toString().trim();
        if (!cmd.isEmpty()) statusText.setText(processor.execute(cmd));
    }

    private void ensureContacts() {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, REQ_CONTACTS);
        else statusText.setText("Contactos autorizados.");
    }

    private void chooseWorkspace() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_TREE);
    }

    public void chooseDocument() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_DOC);
    }

    private void ensureMicThenListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        listenOnce();
    }

    private void ensurePermissionsThenStartHandsFree() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC); return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS); return;
        }
        Intent i = new Intent(this, HandsFreeService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        statusText.setText("Oti IA Plus está atenta. Puedes salir de la app y decir “Oti”.");
    }

    private void listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { statusText.setText("El reconocimiento de voz no está disponible."); return; }
        if (recognizer != null) try { recognizer.destroy(); } catch (Exception ignored) {}
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { statusText.setText("Te escucho…"); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onError(int error) { statusText.setText("No pude entenderte. Intenta otra vez."); }
            @Override public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) statusText.setText(processor.execute(list.get(0)));
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX"); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,5);
        recognizer.startListening(i);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_MIC) statusText.setText(ok ? "Micrófono autorizado. Toca otra vez la función que querías activar." : "Sin micrófono Oti no puede escuchar tu voz.");
        if (requestCode == REQ_NOTIFICATIONS) statusText.setText("Permiso de notificación revisado. Toca otra vez Activar Oti.");
        if (requestCode == REQ_CONTACTS) statusText.setText(ok ? "Contactos autorizados." : "Sin contactos puedes usar números, pero no nombres.");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        if (requestCode == REQ_TREE) { FileWorkspace.saveTree(this,u); statusText.setText("Carpeta autorizada para Oti."); }
        if (requestCode == REQ_DOC) { FileWorkspace.saveLastDocument(this,u); statusText.setText("Archivo guardado como último documento de Oti: " + FileWorkspace.displayName(this,u)); }
    }

    @Override protected void onResume() {
        super.onResume();
        if (voiceLock != null) voiceLock.setChecked(Prefs.voiceLock(this) && VoiceProfileManager.enrolled(this));
    }
    @Override public void onDestroy() {
        if (recognizer != null) try { recognizer.destroy(); } catch (Exception ignored) {}
        if (speaker != null) speaker.shutdown(); super.onDestroy();
    }
}
