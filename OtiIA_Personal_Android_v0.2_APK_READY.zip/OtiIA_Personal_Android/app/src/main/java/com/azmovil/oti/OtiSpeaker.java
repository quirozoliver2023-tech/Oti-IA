package com.azmovil.oti;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class OtiSpeaker {
    private final TextToSpeech tts;
    private volatile boolean ready = false;

    public OtiSpeaker(Context context) {
        tts = new TextToSpeech(context.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("es", "MX"));
                tts.setSpeechRate(1.02f);
                ready = true;
            }
        });
    }

    public void say(String text) {
        if (ready && text != null && !text.trim().isEmpty()) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "oti");
        }
    }

    public void shutdown() {
        tts.stop();
        tts.shutdown();
    }
}
