package com.azmovil.oti;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 101;
    private static final int REQ_NOTIFICATIONS = 102;

    private TextView statusText;
    private EditText commandInput;
    private SpeechRecognizer recognizer;
    private OtiSpeaker speaker;
    private VoiceCommandProcessor processor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusText = findViewById(R.id.statusText);
        commandInput = findViewById(R.id.commandInput);

        speaker = new OtiSpeaker(this);
        processor = new VoiceCommandProcessor(this, speaker);

        findViewById(R.id.speakButton).setOnClickListener(v -> ensureMicThenListen());

        findViewById(R.id.runCommandButton).setOnClickListener(v -> {
            String cmd = commandInput.getText().toString().trim();
            if (!cmd.isEmpty()) {
                statusText.setText("Orden: " + cmd);
                String result = processor.execute(cmd);
                statusText.setText(result);
            }
        });

        findViewById(R.id.startHandsFreeButton).setOnClickListener(v -> ensurePermissionsThenStartHandsFree());

        findViewById(R.id.stopHandsFreeButton).setOnClickListener(v -> {
            stopService(new Intent(this, HandsFreeService.class));
            statusText.setText("Manos libres detenido.");
        });
    }

    private void ensureMicThenListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        listenOnce();
    }

    private void ensurePermissionsThenStartHandsFree() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            statusText.setText("Concede micrófono y vuelve a tocar Manos libres.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
            statusText.setText("Concede notificaciones y vuelve a tocar Manos libres.");
            return;
        }
        startHandsFree();
    }

    private void startHandsFree() {
        Intent i = new Intent(this, HandsFreeService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
        else startService(i);
        statusText.setText("Manos libres activo. Di: “Oti, ...”");
    }

    private void listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.setText("El reconocimiento de voz no está disponible.");
            return;
        }

        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);

        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { statusText.setText("Escuchando..."); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { statusText.setText("Procesando..."); }
            @Override public void onError(int error) { statusText.setText("No entendí. Intenta otra vez."); }
            @Override public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && !list.isEmpty()) {
                    String cmd = list.get(0);
                    statusText.setText("Escuché: " + cmd);
                    String result = processor.execute(cmd);
                    statusText.setText(result);
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        recognizer.startListening(i);
    }

    @Override
    protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (speaker != null) speaker.shutdown();
        super.onDestroy();
    }
}
