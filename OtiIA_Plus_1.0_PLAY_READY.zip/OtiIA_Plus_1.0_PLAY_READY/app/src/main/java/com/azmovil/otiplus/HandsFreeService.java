package com.azmovil.otiplus;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class HandsFreeService extends Service {
    public static final String ACTION_STOP = "com.azmovil.otiplus.STOP";
    public static final String ACTION_PAUSE_FOR_RECORDING = "com.azmovil.otiplus.PAUSE_FOR_RECORDING";
    public static final String ACTION_RESUME_AFTER_RECORDING = "com.azmovil.otiplus.RESUME_AFTER_RECORDING";
    private static final String CHANNEL = "oti_plus_handsfree";
    private static final int NOTIFICATION_ID = 110;

    private SpeechRecognizer recognizer;
    private OtiSpeaker speaker;
    private VoiceCommandProcessor processor;
    private Handler handler;
    private boolean running;
    private boolean pausedForRecording;
    private long conversationUntil;
    private ByteArrayOutputStream utteranceAudio;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper()); speaker = new OtiSpeaker(this);
        processor = new VoiceCommandProcessor(this, speaker); createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopListeningAndSelf(); return START_NOT_STICKY; }
        if (ACTION_PAUSE_FOR_RECORDING.equals(action)) { pausedForRecording = true; destroyRecognizer(); return START_STICKY; }
        if (ACTION_RESUME_AFTER_RECORDING.equals(action)) {
            pausedForRecording = false; if (running) restartSoon(500); return START_STICKY;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { stopSelf(); return START_NOT_STICKY; }
        startForeground(NOTIFICATION_ID, buildNotification());
        if (!running) { running = true; pausedForRecording = false; startRecognizer(); }
        return START_STICKY;
    }

    private void startRecognizer() {
        if (!running || pausedForRecording || !SpeechRecognizer.isRecognitionAvailable(this)) return;
        destroyRecognizer(); utteranceAudio = new ByteArrayOutputStream();
        try {
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this))
                recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            else recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        } catch (Exception e) { recognizer = SpeechRecognizer.createSpeechRecognizer(this); }

        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { utteranceAudio = new ByteArrayOutputStream(); }
            @Override public void onBeginningOfSpeech() { if (speaker != null) speaker.stop(); }
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {
                if (buffer != null && utteranceAudio != null && utteranceAudio.size() < 350000)
                    utteranceAudio.write(buffer,0,buffer.length);
            }
            @Override public void onEndOfSpeech() {}
            @Override public void onError(int error) { restartSoon(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1200 : 650); }
            @Override public void onResults(Bundle results) { handleResults(results); restartSoon(420); }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        try { recognizer.startListening(i); } catch (Exception e) { restartSoon(1000); }
    }

    private void handleResults(Bundle results) {
        ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list == null || list.isEmpty()) return;
        String chosen = null; boolean woke = false;
        for (String heard : list) {
            if (heard == null) continue;
            String n = heard.trim().toLowerCase(Locale.ROOT);
            if (isWake(n)) { chosen = heard; woke = true; break; }
        }
        if (chosen == null && System.currentTimeMillis() < conversationUntil) chosen = list.get(0);
        if (chosen == null) return;

        if (Prefs.voiceLock(this) && VoiceProfileManager.enrolled(this)) {
            byte[] pcm = utteranceAudio == null ? null : utteranceAudio.toByteArray();
            if (!VoiceProfileManager.verify(this, pcm)) {
                speaker.speak("No pude confirmar que seas tú.");
                HistoryManager.log(this,"Orden rechazada porque no coincidió el perfil de voz"); return;
            }
        }

        String stripped = stripWake(chosen);
        if (woke && stripped.isEmpty()) {
            conversationUntil = System.currentTimeMillis() + 25000;
            speaker.speak("Sí, dime."); return;
        }
        conversationUntil = System.currentTimeMillis() + 25000;
        processor.execute(chosen);
    }

    private boolean isWake(String n) {
        return n.equals("oti") || n.startsWith("oti ") || n.startsWith("oye oti") || n.startsWith("hey oti");
    }
    private String stripWake(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceFirst("^(oye\\s+|hey\\s+)?oti[,.!?:;\\s-]*", "").trim(); }

    private void restartSoon(long delayMs) {
        if (!running || pausedForRecording) return;
        handler.removeCallbacksAndMessages(null); handler.postDelayed(this::startRecognizer, delayMs);
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, HandsFreeService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Oti IA Plus está atenta")
                .setContentText("Di “Oti” y después tu orden")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(openPi)
                .addAction(android.R.drawable.ic_media_pause, "DETENER OTI", stopPi).setOngoing(true).build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Oti IA Plus - escucha", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Visible mientras Oti está usando el micrófono para esperar la palabra Oti.");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private void destroyRecognizer() {
        if (recognizer != null) { try { recognizer.cancel(); } catch(Exception ignored){} try { recognizer.destroy(); } catch(Exception ignored){} recognizer = null; }
    }
    private void cleanup() { running = false; if (handler != null) handler.removeCallbacksAndMessages(null); destroyRecognizer(); }
    private void stopListeningAndSelf() { cleanup(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }
    @Override public void onDestroy() { cleanup(); if (speaker != null) speaker.shutdown(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
