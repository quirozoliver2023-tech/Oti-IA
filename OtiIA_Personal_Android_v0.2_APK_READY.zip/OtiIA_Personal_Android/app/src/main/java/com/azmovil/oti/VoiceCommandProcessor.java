package com.azmovil.oti;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class VoiceCommandProcessor {
    private final Context context;
    private final OtiSpeaker speaker;
    private final Map<String, String> packages = new HashMap<>();

    public VoiceCommandProcessor(Context context, OtiSpeaker speaker) {
        this.context = context.getApplicationContext();
        this.speaker = speaker;

        packages.put("whatsapp", "com.whatsapp");
        packages.put("youtube", "com.google.android.youtube");
        packages.put("facebook", "com.facebook.katana");
        packages.put("chrome", "com.android.chrome");
        packages.put("spotify", "com.spotify.music");
        packages.put("tiktok", "com.zhiliaoapp.musically");
    }

    public String execute(String raw) {
        if (raw == null) return "Orden vacía";
        String cmd = normalize(raw);

        if (cmd.equals("oti")) {
            speaker.say("Sí, dime.");
            return "Sí, dime.";
        }
        if (cmd.startsWith("oti ")) cmd = cmd.substring(4).trim();

        if (cmd.equals("inicio") || cmd.contains("ve al inicio")) {
            return global(AccessibilityService.GLOBAL_ACTION_HOME, "Listo.");
        }
        if (cmd.equals("atras") || cmd.contains("regresa")) {
            return global(AccessibilityService.GLOBAL_ACTION_BACK, "Listo.");
        }
        if (cmd.contains("recientes")) {
            return global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Abriendo recientes.");
        }

        if (cmd.startsWith("toca ")) {
            String target = raw.substring(raw.toLowerCase(Locale.ROOT).indexOf("toca ") + 5).trim();
            boolean ok = OtiAccessibilityService.clickText(target);
            speaker.say(ok ? "Listo." : "No encontré ese botón.");
            return ok ? "Tocado: " + target : "No encontrado";
        }

        if (cmd.startsWith("escribe ")) {
            String text = raw.substring(raw.toLowerCase(Locale.ROOT).indexOf("escribe ") + 8);
            boolean ok = OtiAccessibilityService.typeText(text);
            speaker.say(ok ? "Listo." : "Primero toca un cuadro de texto.");
            return ok ? "Texto escrito" : "Sin campo de texto";
        }

        if (cmd.startsWith("abre ")) {
            return open(cmd.substring(5).trim());
        }

        if (cmd.contains("sube volumen") || cmd.contains("mas volumen")) {
            adjustVolume(AudioManager.ADJUST_RAISE);
            speaker.say("Subiendo volumen.");
            return "Volumen +";
        }
        if (cmd.contains("baja volumen") || cmd.contains("menos volumen")) {
            adjustVolume(AudioManager.ADJUST_LOWER);
            speaker.say("Bajando volumen.");
            return "Volumen -";
        }

        if ((cmd.contains("prende") || cmd.contains("enciende") || cmd.contains("activa"))
                && cmd.contains("linterna")) {
            boolean ok = setTorch(true);
            speaker.say(ok ? "Linterna encendida." : "No pude encender la linterna.");
            return ok ? "Linterna ON" : "Error linterna";
        }

        if ((cmd.contains("apaga") || cmd.contains("desactiva"))
                && cmd.contains("linterna")) {
            boolean ok = setTorch(false);
            speaker.say(ok ? "Linterna apagada." : "No pude apagar la linterna.");
            return ok ? "Linterna OFF" : "Error linterna";
        }

        if (cmd.contains("lee") && cmd.contains("notificacion")) {
            List<String> list = OtiNotificationService.getLatest(5);
            if (list.isEmpty()) {
                speaker.say("No tengo notificaciones recientes, o falta darme acceso.");
                return "Sin notificaciones";
            }
            StringBuilder s = new StringBuilder("Tienes ");
            s.append(list.size()).append(" notificaciones recientes. ");
            for (String n : list) s.append(n).append(". ");
            speaker.say(s.toString());
            return s.toString();
        }

        if (cmd.startsWith("llama al ") || cmd.startsWith("llama a ")) {
            String digits = cmd.replaceAll("[^0-9+]", "");
            if (digits.length() >= 7) return callNumber(digits);
            speaker.say("Dime el número completo.");
            return "Falta número";
        }

        if (cmd.contains("ajustes de wifi") || cmd.equals("wifi")) {
            launch(new Intent(Settings.ACTION_WIFI_SETTINGS));
            speaker.say("Abriendo ajustes de wifi.");
            return "Wi-Fi";
        }

        if (cmd.contains("bluetooth")) {
            launch(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            speaker.say("Abriendo bluetooth.");
            return "Bluetooth";
        }

        speaker.say("Todavía no conozco esa orden.");
        return "Orden no reconocida";
    }

    private String open(String what) {
        if (what.contains("camara")) {
            launch(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
            speaker.say("Abriendo cámara.");
            return "Cámara";
        }
        if (what.contains("ajustes") || what.contains("configuracion")) {
            launch(new Intent(Settings.ACTION_SETTINGS));
            speaker.say("Abriendo ajustes.");
            return "Ajustes";
        }

        for (Map.Entry<String, String> e : packages.entrySet()) {
            if (what.contains(e.getKey())) {
                Intent i = context.getPackageManager().getLaunchIntentForPackage(e.getValue());
                if (i != null) {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(i);
                    speaker.say("Abriendo " + e.getKey() + ".");
                    return "Abriendo " + e.getKey();
                }
            }
        }

        speaker.say("No encontré esa aplicación.");
        return "App no encontrada";
    }

    private String global(int action, String phrase) {
        boolean ok = OtiAccessibilityService.global(action);
        speaker.say(ok ? phrase : "Activa primero el control de pantalla.");
        return ok ? phrase : "Accesibilidad desactivada";
    }

    private void adjustVolume(int direction) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
    }

    private boolean setTorch(boolean enabled) {
        if (context.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return false;
        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && facing != null &&
                        facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cm.setTorchMode(id, enabled);
                    return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private String callNumber(String number) {
        if (context.checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            speaker.say("Falta el permiso para hacer llamadas.");
            return "Sin permiso de llamadas";
        }
        try {
            Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(i);
            speaker.say("Llamando.");
            return "Llamando " + number;
        } catch (Exception e) {
            speaker.say("No pude iniciar la llamada.");
            return "Error de llamada";
        }
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    private String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).trim()
                .replace("á", "a").replace("é", "e")
                .replace("í", "i").replace("ó", "o").replace("ú", "u");
    }
}
