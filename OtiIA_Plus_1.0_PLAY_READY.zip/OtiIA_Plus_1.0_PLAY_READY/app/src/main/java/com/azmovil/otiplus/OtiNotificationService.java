package com.azmovil.otiplus;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class OtiNotificationService extends NotificationListenerService {
    private static OtiNotificationService instance;
    private static volatile String lastSummary = "No tengo una notificación reciente para leer.";

    @Override public void onListenerConnected() { super.onListenerConnected(); instance = this; }
    @Override public void onListenerDisconnected() { if (instance == this) instance = null; super.onListenerDisconnected(); }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        Bundle extras = sbn.getNotification().extras;
        String title = str(extras.getCharSequence(Notification.EXTRA_TITLE));
        String text = str(extras.getCharSequence(Notification.EXTRA_TEXT));
        String app = friendlyPackage(sbn.getPackageName());
        StringBuilder b = new StringBuilder("Notificación de ").append(app);
        if (!title.isEmpty()) b.append(", ").append(title);
        if (!text.isEmpty()) b.append(": ").append(text);
        lastSummary = b.toString();
        saveRecent(sbn.getPackageName(), app, title, text, sbn.getPostTime());
    }

    public static String getLastSummary() { return lastSummary; }

    public static String recentSummary(android.content.Context c, int max) {
        try {
            JSONArray a = new JSONArray(Prefs.get(c).getString("notif_history", "[]"));
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < a.length() && i < max; i++) {
                JSONObject o = a.getJSONObject(i);
                if (b.length() > 0) b.append(". ");
                b.append(o.optString("app"));
                String t = o.optString("title"); String x = o.optString("text");
                if (!t.isEmpty()) b.append(" de ").append(t);
                if (!x.isEmpty()) b.append(": ").append(x);
            }
            return b.length() == 0 ? "No tengo notificaciones recientes guardadas." : b.toString();
        } catch (Exception e) { return "No pude leer el historial de notificaciones."; }
    }

    public static boolean reply(String who, String message) {
        OtiNotificationService s = instance;
        if (s == null || message == null || message.trim().isEmpty()) return false;
        String q = norm(who);
        try {
            StatusBarNotification[] ns = s.getActiveNotifications();
            if (ns == null) return false;
            for (StatusBarNotification n : ns) {
                Notification no = n.getNotification();
                if (no == null) continue;
                Bundle e = no.extras;
                String title = str(e.getCharSequence(Notification.EXTRA_TITLE));
                String text = str(e.getCharSequence(Notification.EXTRA_TEXT));
                String hay = norm(title + " " + text + " " + friendlyPackage(n.getPackageName()));
                if (!q.isEmpty() && !hay.contains(q)) continue;
                Notification.Action[] actions = no.actions;
                if (actions == null) continue;
                for (Notification.Action a : actions) {
                    RemoteInput[] inputs = a.getRemoteInputs();
                    if (inputs == null || inputs.length == 0 || a.actionIntent == null) continue;
                    Intent fill = new Intent();
                    Bundle results = new Bundle();
                    for (RemoteInput ri : inputs) results.putCharSequence(ri.getResultKey(), message);
                    RemoteInput.addResultsToIntent(inputs, fill, results);
                    try { a.actionIntent.send(s, 0, fill); return true; }
                    catch (PendingIntent.CanceledException ignored) {}
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void saveRecent(String pkg, String app, String title, String text, long time) {
        try {
            JSONArray old = new JSONArray(Prefs.get(this).getString("notif_history", "[]"));
            JSONArray out = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("pkg", pkg); o.put("app", app); o.put("title", title); o.put("text", text); o.put("time", time);
            out.put(o);
            for (int i = 0; i < old.length() && i < 19; i++) out.put(old.getJSONObject(i));
            Prefs.get(this).edit().putString("notif_history", out.toString()).apply();
        } catch (Exception ignored) {}
    }

    private static String friendlyPackage(String p) {
        if ("com.whatsapp".equals(p)) return "WhatsApp";
        if ("com.google.android.gm".equals(p)) return "Gmail";
        if ("com.facebook.orca".equals(p)) return "Messenger";
        if ("org.telegram.messenger".equals(p)) return "Telegram";
        return p == null ? "una aplicación" : p;
    }
    private static String str(CharSequence s) { return s == null ? "" : s.toString(); }
    private static String norm(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).trim(); }
}
