package com.azmovil.otiplus;

import android.content.Context;
import org.json.JSONObject;
import java.util.Iterator;
import java.util.Locale;

public final class MemoryManager {
    private static final String KEY = "memory_json";
    private MemoryManager() {}

    private static JSONObject load(Context c) {
        try { return new JSONObject(Prefs.get(c).getString(KEY, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    public static synchronized void remember(Context c, String key, String value) {
        try {
            JSONObject o = load(c);
            o.put(normalize(key), value.trim());
            Prefs.get(c).edit().putString(KEY, o.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static synchronized String recall(Context c, String key) {
        JSONObject o = load(c);
        String k = normalize(key);
        String direct = o.optString(k, "");
        if (!direct.isEmpty()) return direct;
        Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String x = it.next();
            if (x.contains(k) || k.contains(x)) return o.optString(x, "");
        }
        return "No tengo eso guardado todavía.";
    }

    public static synchronized String summary(Context c) {
        JSONObject o = load(c);
        Iterator<String> it = o.keys();
        StringBuilder b = new StringBuilder();
        int n = 0;
        while (it.hasNext() && n < 8) {
            String k = it.next();
            if (b.length() > 0) b.append(". ");
            b.append(k).append(": ").append(o.optString(k));
            n++;
        }
        return b.length() == 0 ? "Todavía no tengo recuerdos guardados." : b.toString();
    }

    public static void clear(Context c) { Prefs.get(c).edit().remove(KEY).apply(); }
    private static String normalize(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", " "); }
}
