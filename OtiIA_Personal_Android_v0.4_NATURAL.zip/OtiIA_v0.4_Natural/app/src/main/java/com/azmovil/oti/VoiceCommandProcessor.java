package com.azmovil.oti;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceCommandProcessor {
    private final Context context;
    private final OtiSpeaker speaker;
    private final Map<String, String> packages = new LinkedHashMap<>();

    public VoiceCommandProcessor(Context context, OtiSpeaker speaker) {
        this.context = context.getApplicationContext();
        this.speaker = speaker;

        packages.put("whatsapp", "com.whatsapp");
        packages.put("youtube", "com.google.android.youtube");
        packages.put("facebook", "com.facebook.katana");
        packages.put("chrome", "com.android.chrome");
        packages.put("spotify", "com.spotify.music");
        packages.put("tiktok", "com.zhiliaoapp.musically");
        packages.put("instagram", "com.instagram.android");
        packages.put("telegram", "org.telegram.messenger");
        packages.put("gmail", "com.google.android.gm");
        packages.put("maps", "com.google.android.apps.maps");
        packages.put("google maps", "com.google.android.apps.maps");
    }

    public String execute(String raw) {
        if (raw == null || raw.trim().isEmpty()) return say("No escuché ninguna orden.");

        String cmd = normalize(raw);
        if (cmd.equals("oti") || cmd.equals("oye oti") || cmd.equals("hey oti")) {
            return say("Sí, dime.");
        }
        cmd = stripWakeWord(cmd);

        // Órdenes naturales para abrir apps o funciones.
        String app = detectApp(cmd);
        if (app != null && looksLikeOpenIntent(cmd)) {
            return open(app);
        }

        // Búsquedas: “busca rancheras en YouTube”, “búscame tacos en Google”.
        if (containsAny(cmd, "busca", "buscar", "buscame", "encuentra", "investiga")) {
            if (cmd.contains("youtube")) {
                String q = cleanupSearchQuery(cmd, "youtube");
                if (!q.isEmpty()) return openUrl("https://www.youtube.com/results?search_query=" + enc(q), "Buscando en YouTube.");
            }
            if (cmd.contains("google") || cmd.contains("internet") || cmd.contains("web")) {
                String q = cleanupSearchQuery(cmd, "google");
                if (!q.isEmpty()) return openUrl("https://www.google.com/search?q=" + enc(q), "Buscando en Google.");
            }
        }

        // Navegación: “llévame al zócalo”, “cómo llego a Pinotepa”.
        if (containsAny(cmd, "llevame a ", "llevame al ", "como llego a ", "navega a ", "ruta a ", "ir a ")) {
            String place = afterFirst(cmd, new String[]{"llevame al ", "llevame a ", "como llego a ", "navega a ", "ruta a ", "ir a "});
            if (!place.isEmpty()) {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + enc(place)));
                i.setPackage("com.google.android.apps.maps");
                if (i.resolveActivity(context.getPackageManager()) == null) {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + enc(place)));
                }
                launch(i);
                return say("Abriendo la ruta a " + place + ".");
            }
        }

        // Cámara y ajustes, incluso si el usuario no dice “abre”.
        if (containsAny(cmd, "camara", "tomar foto", "sacar foto", "quiero una foto")) {
            return open("camara");
        }
        if (containsAny(cmd, "configuracion", "ajustes del telefono", "ajustes")) {
            return open("ajustes");
        }
        if (cmd.matches(".*\\bwi ?fi\\b.*") || cmd.contains("internet inalambrico")) {
            launch(new Intent(Settings.ACTION_WIFI_SETTINGS));
            return say("Abriendo los ajustes de Wi-Fi.");
        }
        if (cmd.contains("bluetooth")) {
            launch(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
            return say("Abriendo Bluetooth.");
        }

        // Volumen con frases distintas.
        if (containsAny(cmd, "sube el volumen", "sube volumen", "mas volumen", "aumenta el volumen", "ponlo mas fuerte", "mas fuerte")) {
            adjustVolume(AudioManager.ADJUST_RAISE);
            return say("Subiendo volumen.");
        }
        if (containsAny(cmd, "baja el volumen", "baja volumen", "menos volumen", "disminuye el volumen", "ponlo mas bajo", "mas bajo")) {
            adjustVolume(AudioManager.ADJUST_LOWER);
            return say("Bajando volumen.");
        }
        if (containsAny(cmd, "silencio", "silencia", "quita el sonido", "mute")) {
            AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI);
            return say("Silenciando.");
        }

        // Llamadas por número. Por seguridad abre el marcador y el usuario confirma.
        if (containsAny(cmd, "llama", "marcale", "marca al", "marca a")) {
            String digits = cmd.replaceAll("[^0-9+]", "");
            if (digits.length() >= 7) return openDialer(digits);
            return say("Puedo preparar la llamada si me dices el número.");
        }

        // Compartir un texto por WhatsApp sin leer contactos ni enviar silenciosamente.
        if (cmd.contains("whatsapp") && containsAny(cmd, "manda", "envia", "enviar", "escribe", "dile")) {
            String text = extractMessage(cmd);
            if (!text.isEmpty()) return shareWhatsApp(text);
            return open("whatsapp");
        }

        // Frases coloquiales de apertura, incluso sin verbo “abrir”.
        if (app != null) return open(app);

        // Atajos web naturales.
        if (containsAny(cmd, "abre google", "pon google", "quiero google")) {
            return openUrl("https://www.google.com", "Abriendo Google.");
        }

        if (containsAny(cmd, "inicio", "atras", "recientes", "toca ", "presiona ", "escribe ", "notificacion", "linterna")) {
            return say("Entendí la orden, pero esa acción necesita el módulo avanzado de control del teléfono.");
        }

        return say("No entendí bien esa orden. Puedes hablarme normal, por ejemplo: abre YouTube, busca música en Google o llévame al centro.");
    }

    private boolean looksLikeOpenIntent(String cmd) {
        return containsAny(cmd,
                "abre", "abrir", "entra", "entra a", "pon", "ponme", "quiero ver", "quiero abrir",
                "ve a", "vamos a", "inicia", "lanza", "abre la app", "abre aplicacion");
    }

    private String detectApp(String cmd) {
        for (String key : packages.keySet()) {
            if (cmd.contains(key)) return key;
        }
        if (cmd.contains("camara")) return "camara";
        if (cmd.contains("configuracion") || cmd.contains("ajustes")) return "ajustes";
        return null;
    }

    private String open(String what) {
        if (what == null) return say("No encontré qué abrir.");
        what = normalize(what);

        if (what.contains("camara")) {
            launch(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));
            return say("Abriendo cámara.");
        }
        if (what.contains("ajustes") || what.contains("configuracion")) {
            launch(new Intent(Settings.ACTION_SETTINGS));
            return say("Abriendo ajustes.");
        }

        for (Map.Entry<String, String> e : packages.entrySet()) {
            if (what.contains(e.getKey()) || e.getKey().contains(what)) {
                Intent i = context.getPackageManager().getLaunchIntentForPackage(e.getValue());
                if (i != null) {
                    launch(i);
                    return say("Abriendo " + friendlyName(e.getKey()) + ".");
                }
                return say("No encontré " + friendlyName(e.getKey()) + " instalado.");
            }
        }

        return say("No encontré esa aplicación.");
    }

    private String shareWhatsApp(String message) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.setPackage("com.whatsapp");
            i.putExtra(Intent.EXTRA_TEXT, message);
            launch(i);
            return say("Abrí WhatsApp con el mensaje preparado. Elige el contacto y confirma el envío.");
        } catch (Exception e) {
            return say("No pude abrir WhatsApp.");
        }
    }

    private String extractMessage(String cmd) {
        String s = cmd;
        s = s.replaceFirst("^.*?whatsapp", "").trim();
        s = s.replaceFirst("^(a|por|para)?\\s*(manda|mandar|envia|enviar|escribe|dile)?\\s*(que)?\\s*", "").trim();
        if (s.isEmpty()) {
            Matcher m = Pattern.compile("(?:manda|envia|escribe|dile)(?: por whatsapp)?(?: que)? (.+)$").matcher(cmd);
            if (m.find()) s = m.group(1).trim();
        }
        return s;
    }

    private String cleanupSearchQuery(String cmd, String service) {
        String q = cmd;
        q = q.replace(service, " ");
        q = q.replace("en youtube", " ").replace("en google", " ").replace("en internet", " ").replace("en la web", " ");
        q = q.replaceFirst("^(busca|buscar|buscame|encuentra|investiga)(me)?\\s*", "");
        return q.replaceAll("\\s+", " ").trim();
    }

    private String openUrl(String url, String spoken) {
        try {
            launch(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            return say(spoken);
        } catch (Exception e) {
            return say("No pude abrirlo.");
        }
    }

    private void adjustVolume(int direction) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
    }

    private String openDialer(String number) {
        try {
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
            launch(i);
            return say("Abrí el teléfono con el número listo. Tú confirmas la llamada.");
        } catch (Exception e) {
            return say("No pude abrir el teléfono.");
        }
    }

    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(i);
    }

    private String say(String text) {
        speaker.say(text);
        return text;
    }

    private String stripWakeWord(String cmd) {
        String out = cmd;
        out = out.replaceFirst("^(oye |hey )?oti[, ]*", "").trim();
        return out;
    }

    private boolean containsAny(String text, String... values) {
        for (String v : values) if (text.contains(v)) return true;
        return false;
    }

    private String afterFirst(String text, String[] markers) {
        for (String m : markers) {
            int p = text.indexOf(m);
            if (p >= 0) return text.substring(p + m.length()).trim();
        }
        return "";
    }

    private String friendlyName(String key) {
        if (key.equals("google maps")) return "Google Maps";
        if (key.equals("maps")) return "Maps";
        if (key.equals("whatsapp")) return "WhatsApp";
        if (key.equals("youtube")) return "YouTube";
        if (key.equals("tiktok")) return "TikTok";
        if (key.equals("gmail")) return "Gmail";
        if (key.equals("spotify")) return "Spotify";
        if (key.equals("instagram")) return "Instagram";
        if (key.equals("telegram")) return "Telegram";
        if (key.equals("facebook")) return "Facebook";
        if (key.equals("chrome")) return "Chrome";
        return key;
    }

    private String enc(String s) {
        try {
            return URLEncoder.encode(s, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return s.replace(" ", "+");
        }
    }

    private String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).trim()
                .replace("á", "a").replace("é", "e")
                .replace("í", "i").replace("ó", "o").replace("ú", "u")
                .replace("ü", "u").replaceAll("[¿?¡!]", "")
                .replaceAll("\\s+", " ");
    }
}
