package com.azmovil.otiplus;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CloudSettingsActivity extends Activity {
    private EditText key, model;
    private TextView status;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(36,36,36,36);
        TextView t = new TextView(this); t.setText("IA en la nube · opcional"); t.setTextSize(25); l.addView(t);
        TextView info = new TextView(this); info.setText("Los comandos del teléfono funcionan sin clave. Para preguntas complejas puedes añadir una clave de OpenAI. La clave se cifra con Android Keystore en este teléfono."); info.setPadding(0,18,0,18); l.addView(info);
        key = new EditText(this); key.setHint("Clave API"); key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); l.addView(key);
        model = new EditText(this); model.setHint("Modelo"); model.setText(Prefs.get(this).getString("cloud_model", "gpt-5.6-luna")); l.addView(model);
        Button save = new Button(this); save.setText("Guardar configuración"); save.setOnClickListener(v -> save()); l.addView(save);
        Button clear = new Button(this); clear.setText("Borrar clave"); clear.setOnClickListener(v -> { SecretStore.clear(this,"openai"); status.setText("Clave borrada."); }); l.addView(clear);
        status = new TextView(this); status.setPadding(0,18,0,0); status.setText(SecretStore.get(this,"openai") == null ? "No hay clave guardada." : "Hay una clave guardada de forma cifrada."); l.addView(status);
        setContentView(l);
    }
    private void save() {
        String k = key.getText().toString().trim(); String m = model.getText().toString().trim();
        if (!k.isEmpty()) SecretStore.put(this,"openai",k);
        if (m.isEmpty()) m = "gpt-5.6-luna";
        Prefs.get(this).edit().putString("cloud_model",m).apply();
        key.setText(""); status.setText("Configuración guardada.");
    }
}
