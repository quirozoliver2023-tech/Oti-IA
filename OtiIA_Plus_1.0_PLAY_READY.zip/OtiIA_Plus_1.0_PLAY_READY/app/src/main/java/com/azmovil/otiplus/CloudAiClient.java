package com.azmovil.otiplus;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class CloudAiClient {
    public interface Callback { void done(String answer); }
    private CloudAiClient() {}
    public static boolean configured(Context c) { String k = SecretStore.get(c,"openai"); return k != null && !k.trim().isEmpty(); }

    public static void ask(Context c, String question, String screenContext, Callback cb) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            String answer;
            try {
                String key = SecretStore.get(app,"openai");
                if (key == null || key.isEmpty()) throw new IllegalStateException("Sin clave");
                String model = Prefs.get(app).getString("cloud_model", "gpt-5.6-luna");
                JSONObject body = new JSONObject();
                body.put("model", model);
                body.put("store", false);
                body.put("max_output_tokens", 350);
                body.put("instructions", "Eres Oti IA Plus, asistente personal Android. Responde en español de México, breve y práctico. No inventes haber ejecutado acciones del teléfono. Nunca pidas contraseñas ni datos bancarios.");
                String input = question;
                if (screenContext != null && !screenContext.trim().isEmpty()) input += "\n\nContexto visible de pantalla:\n" + screenContext;
                body.put("input", input);
                HttpURLConnection h = (HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
                h.setRequestMethod("POST"); h.setConnectTimeout(15000); h.setReadTimeout(30000); h.setDoOutput(true);
                h.setRequestProperty("Authorization", "Bearer " + key); h.setRequestProperty("Content-Type", "application/json");
                try (OutputStream os = h.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                int code = h.getResponseCode();
                BufferedReader r = new BufferedReader(new InputStreamReader(code >= 200 && code < 300 ? h.getInputStream() : h.getErrorStream(), StandardCharsets.UTF_8));
                StringBuilder raw = new StringBuilder(); String line; while ((line = r.readLine()) != null) raw.append(line);
                if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code);
                answer = extractText(new JSONObject(raw.toString()));
                if (answer == null || answer.trim().isEmpty()) answer = "La IA en la nube respondió sin texto.";
            } catch (Exception e) { answer = "No pude consultar la IA en la nube en este momento."; }
            String a = answer;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> cb.done(a));
        }).start();
    }

    private static String extractText(JSONObject root) {
        StringBuilder b = new StringBuilder();
        JSONArray out = root.optJSONArray("output"); if (out == null) return null;
        for (int i = 0; i < out.length(); i++) {
            JSONObject item = out.optJSONObject(i); if (item == null) continue;
            JSONArray content = item.optJSONArray("content"); if (content == null) continue;
            for (int j = 0; j < content.length(); j++) {
                JSONObject part = content.optJSONObject(j); if (part == null) continue;
                if ("output_text".equals(part.optString("type"))) {
                    if (b.length() > 0) b.append('\n'); b.append(part.optString("text"));
                }
            }
        }
        return b.toString().trim();
    }
}
