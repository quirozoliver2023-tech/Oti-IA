package com.azmovil.otiplus;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Queue;

public final class UiAutomationQueue {
    public static final class Step {
        final String[] labels;
        final long notBefore;
        int attempts;
        Step(long delayMs, String... labels) {
            this.labels = labels;
            this.notBefore = System.currentTimeMillis() + delayMs;
        }
        public String toString() { return Arrays.toString(labels); }
    }
    private static final Queue<Step> Q = new ArrayDeque<>();
    private static long expiresAt;
    private UiAutomationQueue() {}
    public static synchronized void clear() { Q.clear(); expiresAt = 0; }
    public static synchronized void begin(long timeoutMs) { Q.clear(); expiresAt = System.currentTimeMillis() + timeoutMs; }
    public static synchronized void add(long delayMs, String... labels) { Q.add(new Step(delayMs, labels)); }
    public static synchronized Step peek() {
        if (System.currentTimeMillis() > expiresAt) { clear(); return null; }
        return Q.peek();
    }
    public static synchronized void success() { Q.poll(); }
    public static synchronized boolean isEmpty() { return Q.isEmpty(); }
}
