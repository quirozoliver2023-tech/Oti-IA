package com.azmovil.otiplus;

import java.util.ArrayList;
import java.util.List;

/**
 * Huella acústica ligera para personalización local. No es biometría de seguridad.
 * Trabaja con los buffers PCM big-endian de SpeechRecognizer cuando el motor los entrega.
 */
public final class VoiceFingerprint {
    private VoiceFingerprint() {}

    public static float[] extract(byte[] pcm) {
        if (pcm == null || pcm.length < 4096) return null;
        int total = pcm.length / 2;
        int step = Math.max(1, total / 12000);
        List<Double> s = new ArrayList<>();
        for (int i = 0; i + 1 < pcm.length; i += 2 * step) {
            int hi = pcm[i];
            int lo = pcm[i + 1] & 0xff;
            short v = (short)((hi << 8) | lo);
            s.add(v / 32768.0);
        }
        if (s.size() < 1000) return null;
        int n = s.size();
        float[] f = new float[50];

        double sum2 = 0, sumAbs = 0;
        int zc = 0;
        for (int i = 0; i < n; i++) {
            double x = s.get(i);
            sum2 += x * x; sumAbs += Math.abs(x);
            if (i > 0 && ((x >= 0) != (s.get(i - 1) >= 0))) zc++;
        }
        f[0] = (float)Math.sqrt(sum2 / n);
        f[1] = (float)(sumAbs / n);
        f[2] = (float)zc / n;

        // 15 bandas temporales de energía: conserva timbre/ritmo de la frase sin guardar audio.
        int bands = 15;
        for (int b = 0; b < bands; b++) {
            int a = b * n / bands, e = (b + 1) * n / bands;
            double v = 0;
            for (int i = a; i < e; i++) v += s.get(i) * s.get(i);
            f[3 + b] = (float)Math.sqrt(v / Math.max(1, e - a));
        }

        // Correlaciones normalizadas aproximan periodicidad/pitch sin depender del sample-rate exacto.
        int base = 18;
        int[] lags = {12,16,20,24,28,32,36,40,48,56,64,72,80,96,112,128};
        for (int j = 0; j < lags.length; j++) {
            int lag = lags[j]; double num = 0, a2 = 0, b2 = 0;
            for (int i = lag; i < n; i += 2) {
                double a = s.get(i), b = s.get(i - lag);
                num += a * b; a2 += a * a; b2 += b * b;
            }
            f[base + j] = (float)(num / (Math.sqrt(a2 * b2) + 1e-9));
        }

        // Espectro grueso sobre una ventana central.
        int offset = Math.max(0, n / 2 - 512);
        int win = Math.min(1024, n - offset);
        int specBase = 34;
        for (int k = 1; k <= 16; k++) {
            double re = 0, im = 0;
            for (int t = 0; t < win; t += 2) {
                double angle = 2.0 * Math.PI * k * t / win;
                double x = s.get(offset + t);
                re += x * Math.cos(angle); im -= x * Math.sin(angle);
            }
            f[specBase + k - 1] = (float)Math.log1p(Math.sqrt(re * re + im * im));
        }
        normalize(f);
        return f;
    }

    public static float similarity(float[] a, float[] b) {
        if (a == null || b == null || a.length != b.length) return -1f;
        double dot = 0, aa = 0, bb = 0;
        for (int i = 0; i < a.length; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        return (float)(dot / (Math.sqrt(aa * bb) + 1e-9));
    }

    public static float[] average(List<float[]> xs) {
        if (xs == null || xs.isEmpty()) return null;
        int n = xs.get(0).length; float[] out = new float[n]; int count = 0;
        for (float[] x : xs) {
            if (x == null || x.length != n) continue;
            for (int i = 0; i < n; i++) out[i] += x[i]; count++;
        }
        if (count == 0) return null;
        for (int i = 0; i < n; i++) out[i] /= count;
        normalize(out); return out;
    }

    private static void normalize(float[] f) {
        double s = 0; for (float v : f) s += v * v;
        double d = Math.sqrt(s) + 1e-9;
        for (int i = 0; i < f.length; i++) f[i] = (float)(f[i] / d);
    }
}
