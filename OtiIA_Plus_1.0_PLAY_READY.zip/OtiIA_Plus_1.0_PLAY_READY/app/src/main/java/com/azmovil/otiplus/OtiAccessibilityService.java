package com.azmovil.otiplus;

import android.accessibilityservice.AccessibilityService;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class OtiAccessibilityService extends AccessibilityService {
    private static OtiAccessibilityService instance;
    public static OtiAccessibilityService getInstance() { return instance; }

    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { processQueuedAutomation(); }
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public boolean goHome() { return performGlobalAction(GLOBAL_ACTION_HOME); }
    public boolean goBack() { return performGlobalAction(GLOBAL_ACTION_BACK); }
    public boolean showRecents() { return performGlobalAction(GLOBAL_ACTION_RECENTS); }

    public boolean clickVisibleText(String wanted) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || wanted == null || wanted.trim().isEmpty()) return false;
        try {
            List<AccessibilityNodeInfo> direct = root.findAccessibilityNodeInfosByText(wanted);
            if (direct != null) for (AccessibilityNodeInfo n : direct) if (clickNodeOrParent(n)) return true;
        } catch (Exception ignored) {}
        return findAndClick(root, normalize(wanted));
    }

    public boolean clickAny(String... labels) {
        if (labels == null) return false;
        for (String s : labels) if (s != null && clickVisibleText(s)) return true;
        return false;
    }

    private boolean findAndClick(AccessibilityNodeInfo node, String q) {
        if (node == null) return false;
        String a = normalize(str(node.getText()));
        String b = normalize(str(node.getContentDescription()));
        if ((!a.isEmpty() && (a.equals(q) || a.contains(q))) || (!b.isEmpty() && (b.equals(q) || b.contains(q)))) {
            if (clickNodeOrParent(node)) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (findAndClick(child, q)) return true;
        }
        return false;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        for (int i = 0; i < 7 && cur != null; i++) {
            if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            cur = cur.getParent();
        }
        return false;
    }

    public boolean typeIntoFocusedField(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused == null || !focused.isEditable()) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    public boolean scrollForward() { return scroll(getRootInActiveWindow(), AccessibilityNodeInfo.ACTION_SCROLL_FORWARD); }
    public boolean scrollBackward() { return scroll(getRootInActiveWindow(), AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD); }
    private boolean scroll(AccessibilityNodeInfo node, int action) {
        if (node == null) return false;
        if (node.isScrollable() && node.performAction(action)) return true;
        for (int i = 0; i < node.getChildCount(); i++) if (scroll(node.getChild(i), action)) return true;
        return false;
    }

    public String describeScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "No puedo leer esta pantalla. Activa Accesibilidad de Oti.";
        Set<String> texts = new LinkedHashSet<>();
        collect(root, texts, 0);
        StringBuilder b = new StringBuilder();
        int n = 0;
        for (String s : texts) {
            if (s.length() < 2) continue;
            if (b.length() > 0) b.append(". ");
            b.append(s);
            if (++n >= 12 || b.length() > 650) break;
        }
        return b.length() == 0 ? "No encontré texto legible en la pantalla." : b.toString();
    }

    public String findLikelyError() {
        String all = describeScreen();
        String low = normalize(all);
        String[] keys = {"error", "fallo", "falló", "no se pudo", "invalido", "inválido", "denegado", "bloqueado", "advertencia"};
        for (String k : keys) if (low.contains(normalize(k))) return all;
        return "No veo un mensaje de error claro. En la pantalla aparece: " + all;
    }

    private void collect(AccessibilityNodeInfo n, Set<String> out, int depth) {
        if (n == null || depth > 18 || out.size() > 50) return;
        add(out, str(n.getText())); add(out, str(n.getContentDescription()));
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), out, depth + 1);
    }
    private void add(Set<String> out, String s) { if (s != null && !s.trim().isEmpty()) out.add(s.trim()); }

    private void processQueuedAutomation() {
        UiAutomationQueue.Step s = UiAutomationQueue.peek();
        if (s == null || System.currentTimeMillis() < s.notBefore) return;
        if (clickAny(s.labels)) UiAutomationQueue.success();
        else if (++s.attempts > 12) UiAutomationQueue.clear();
    }

    private static String str(CharSequence s) { return s == null ? "" : s.toString(); }
    private static String normalize(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.trim().replaceAll("\\s+", " ");
    }
}
