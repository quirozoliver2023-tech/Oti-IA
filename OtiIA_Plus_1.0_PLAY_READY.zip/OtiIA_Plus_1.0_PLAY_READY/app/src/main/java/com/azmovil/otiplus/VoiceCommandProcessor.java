package com.azmovil.otiplus;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.provider.Settings;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceCommandProcessor {
    private final Context context;
    private final OtiSpeaker speaker;
    private final Map<String, String> packages = new LinkedHashMap<>();

    public VoiceCommandProcessor(Context context, OtiSpeaker speaker) {
        this.context = context.getApplicationContext(); this.speaker = speaker;
        packages.put("whatsapp", "com.whatsapp"); packages.put("youtube", "com.google.android.youtube");
        packages.put("facebook", "com.facebook.katana"); packages.put("messenger", "com.facebook.orca");
        packages.put("chrome", "com.android.chrome"); packages.put("spotify", "com.spotify.music");
        packages.put("tiktok", "com.zhiliaoapp.musically"); packages.put("instagram", "com.instagram.android");
        packages.put("telegram", "org.telegram.messenger"); packages.put("gmail", "com.google.android.gm");
        packages.put("maps", "com.google.android.apps.maps"); packages.put("mercado pago", "com.mercadopago.wallet");
    }

    public String execute(String raw) { return executeInternal(raw, true); }

    private String executeInternal(String raw, boolean allowRoutine) {
        if (raw == null || raw.trim().isEmpty()) return say("No escuché ninguna orden.");
        String cmd = stripWakeWord(normalize(raw));
        if (cmd.isEmpty()) return say("Sí, dime.");

        // Seguridad: nunca escribe contraseñas ni ejecuta movimientos de dinero automáticamente.
        if (containsAny(cmd,"contraseña","contrasena","pin bancario","cvv","transferencia","transfiere dinero","paga con","comprar con tarjeta")) {
            HistoryManager.log(context,"Bloqueó automatización sensible: " + cmd);
            return say("Esa acción es sensible. Puedo abrir la aplicación correspondiente, pero la contraseña, el pago o la transferencia los confirmas tú en pantalla.");
        }

        // Memoria personal.
        if (cmd.startsWith("recuerda que ")) {
            String body = cmd.substring("recuerda que ".length()).trim();
            int p = body.indexOf(" es ");
            if (p > 0) {
                String k = body.substring(0,p).trim(), v = body.substring(p+4).trim();
                MemoryManager.remember(context,k,v); HistoryManager.log(context,"Guardó memoria: " + k);
                return say("Lo recordaré.");
            }
        }
        if (cmd.startsWith("que recuerdas de ") || cmd.startsWith("qué recuerdas de ")) {
            String q = cmd.replaceFirst("^(que|qué) recuerdas de ","").trim(); return say(MemoryManager.recall(context,q));
        }
        if (equalsAny(cmd,"que recuerdas","qué recuerdas","dime lo que recuerdas")) return say(MemoryManager.summary(context));
        if (containsAny(cmd,"borra mi memoria","elimina mi memoria")) {
            launchSecurity("CLEAR_MEMORY","Borrar memoria personal y rutinas de Oti"); return say("Te pediré huella o PIN antes de borrar la memoria.");
        }

        // Rutinas personales.
        Matcher when = Pattern.compile("^cuando diga (.+?)[,:]\\s*(.+)$").matcher(cmd);
        if (when.find()) {
            RoutineManager.save(context,when.group(1),when.group(2)); HistoryManager.log(context,"Creó rutina: " + when.group(1));
            return say("Rutina guardada. Cuando digas " + when.group(1) + ", ejecutaré esos pasos.");
        }
        Matcher cr = Pattern.compile("^crea rutina (.+?) para (.+)$").matcher(cmd);
        if (cr.find()) {
            RoutineManager.save(context,cr.group(1),cr.group(2)); HistoryManager.log(context,"Creó rutina: " + cr.group(1));
            return say("Rutina " + cr.group(1) + " guardada.");
        }
        if (containsAny(cmd,"mis rutinas","que rutinas tengo","qué rutinas tengo")) return say(RoutineManager.summary(context));
        if (allowRoutine) {
            String routine = RoutineManager.find(context,cmd);
            if (routine != null) {
                HistoryManager.log(context,"Ejecutó rutina: " + cmd);
                String[] actions = routine.split("\\s+(?:y luego|despues|después)\\s+|;");
                String last = "Rutina ejecutada.";
                for (String a : actions) if (!a.trim().isEmpty()) last = executeInternal(a.trim(), false);
                return last;
            }
        }

        OtiAccessibilityService a11y = OtiAccessibilityService.getInstance();

        // Control de pantalla.
        if (equalsAny(cmd,"inicio","ve al inicio","pantalla de inicio","vete al inicio")) return action(a11y != null && a11y.goHome(),"Fui al inicio","Activa Accesibilidad de Oti para usar Inicio.");
        if (equalsAny(cmd,"atras","atrás","regresa","regresar","volver","vuelve atras","vuelve atrás")) return action(a11y != null && a11y.goBack(),"Regresé","Activa Accesibilidad de Oti para regresar.");
        if (containsAny(cmd,"recientes","aplicaciones recientes","apps recientes")) return action(a11y != null && a11y.showRecents(),"Abrí recientes","Activa Accesibilidad de Oti para abrir recientes.");
        if (cmd.startsWith("toca ") || cmd.startsWith("presiona ") || cmd.startsWith("pulsa ")) {
            String target = cmd.replaceFirst("^(toca|presiona|pulsa)\\s+","").trim();
            return action(a11y != null && a11y.clickVisibleText(target),"Toqué " + target,"No encontré ese control visible o Accesibilidad no está activa.");
        }
        if (cmd.startsWith("escribe ") || cmd.startsWith("pon el texto ")) {
            String text = cmd.replaceFirst("^(escribe|pon el texto)\\s+","").trim();
            return action(a11y != null && a11y.typeIntoFocusedField(text),"Escribí el texto","Toca primero un campo de texto y activa Accesibilidad.");
        }
        if (containsAny(cmd,"desliza abajo","baja la pantalla","scroll abajo")) return action(a11y != null && a11y.scrollForward(),"Deslicé hacia abajo","No encontré una zona desplazable.");
        if (containsAny(cmd,"desliza arriba","sube la pantalla","scroll arriba")) return action(a11y != null && a11y.scrollBackward(),"Deslicé hacia arriba","No encontré una zona desplazable.");
        if (containsAny(cmd,"que hay en pantalla","qué hay en pantalla","lee la pantalla","que aparece en pantalla","qué aparece en pantalla")) return say(a11y == null ? "Activa Accesibilidad para que pueda leer la pantalla." : a11y.describeScreen());
        if (containsAny(cmd,"que error aparece","qué error aparece","busca el error")) return say(a11y == null ? "Activa Accesibilidad para revisar la pantalla." : a11y.findLikelyError());
        if (containsAny(cmd,"que significa esto","qué significa esto","explicame esto","explícame esto")) {
            String screen = a11y == null ? "" : a11y.describeScreen();
            if (CloudAiClient.configured(context)) {
                CloudAiClient.ask(context,"Explícame de forma sencilla lo que aparece aquí.",screen,answer -> speaker.speak(answer));
                return "Consultando la IA con el contenido visible autorizado.";
            }
            return say(screen.isEmpty() ? "Activa Accesibilidad o configura la IA en nube para analizar la pantalla." : screen);
        }

        // Notificaciones y respuestas.
        Matcher reply = Pattern.compile("^responde(?:le)? a (.+?) que (.+)$").matcher(cmd);
        if (reply.find()) {
            boolean ok = OtiNotificationService.reply(reply.group(1),reply.group(2));
            return action(ok,"Respondí la notificación de " + reply.group(1),"No encontré una notificación respondible de " + reply.group(1) + ".");
        }
        if (containsAny(cmd,"lee mi ultima notificacion","lee mi última notificación","ultima notificacion","última notificación","quien me escribio","quién me escribió")) return say(OtiNotificationService.getLastSummary());
        if (containsAny(cmd,"lee mis notificaciones","que notificaciones tengo","qué notificaciones tengo")) return say(OtiNotificationService.recentSummary(context,5));

        // Grabadora. Mientras graba, detener también está disponible en la notificación persistente.
        if (containsAny(cmd,"empieza a grabar audio","inicia grabacion","inicia grabación","graba audio","empieza a grabar")) {
            Intent i = new Intent(context,RecorderService.class).setAction(RecorderService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i); else context.startService(i);
            HistoryManager.log(context,"Solicitó iniciar grabación de audio"); return say("Empezando la grabación. Verás un aviso permanente con el botón para detenerla.");
        }
        if (containsAny(cmd,"deten la grabacion","detén la grabación","termina la grabacion","termina la grabación","para de grabar")) {
            context.startService(new Intent(context,RecorderService.class).setAction(RecorderService.ACTION_STOP));
            return say("Deteniendo y guardando la grabación.");
        }
        Matcher audioTo = Pattern.compile("^(?:manda|envia|envía|comparte) (?:el )?(?:ultimo |último )?audio (?:por whatsapp )?(?:a )(.+)$").matcher(cmd);
        if (audioTo.find()) {
            Uri u = RecorderService.lastRecordingUri(context);
            if (u == null) return say("No encontré una grabación reciente. Primero dime que empiece a grabar audio.");
            if (FileWorkspace.share(context,u,"com.whatsapp")) {
                if (OtiAccessibilityService.getInstance() != null) {
                    UiAutomationQueue.begin(12000); UiAutomationQueue.add(1200,audioTo.group(1));
                    if (Prefs.autoActions(context)) UiAutomationQueue.add(700,"Enviar","Send");
                }
                return done("Abrí WhatsApp para compartir el audio con " + audioTo.group(1));
            }
            return say("No pude compartir la grabación.");
        }
        if (containsAny(cmd,"manda el ultimo audio por whatsapp","envia el ultimo audio por whatsapp","comparte el ultimo audio por whatsapp")) {
            Uri u = RecorderService.lastRecordingUri(context);
            return action(FileWorkspace.share(context,u,"com.whatsapp"),"Abrí WhatsApp para compartir tu última grabación","No encontré una grabación reciente para compartir.");
        }

        // WhatsApp: mensajes, llamadas y videollamadas.
        Matcher wm = Pattern.compile("^(?:dile a|manda(?:le)? a|envia(?:le)? a|envía(?:le)? a) (.+?) por whatsapp(?: que)? (.+)$").matcher(cmd);
        if (wm.find()) return sendWhatsApp(wm.group(1),wm.group(2));
        Matcher wm2 = Pattern.compile("^por whatsapp (?:dile a|manda(?:le)? a|envia(?:le)? a|envía(?:le)? a) (.+?)(?: que) (.+)$").matcher(cmd);
        if (wm2.find()) return sendWhatsApp(wm2.group(1),wm2.group(2));
        Matcher wv = Pattern.compile("^(?:haz |inicia |empieza )?(videollamada|video llamada) (?:a|con) (.+?)(?: por whatsapp)?$").matcher(cmd);
        if (wv.find()) return whatsAppCall(wv.group(2),true);
        Matcher wc = Pattern.compile("^(?:llama|marca) (?:a )?(.+?) por whatsapp$").matcher(cmd);
        if (wc.find()) return whatsAppCall(wc.group(1),false);
        Matcher chat = Pattern.compile("^abre whatsapp (?:con|de) (.+)$").matcher(cmd);
        if (chat.find()) return openWhatsAppChat(chat.group(1));

        // Llamadas normales por contacto/número. Usa el marcador y Accesibilidad opcional para confirmar.
        Matcher call = Pattern.compile("^(?:llama|marca) (?:a |al )?(.+)$").matcher(cmd);
        if (call.find() && !cmd.contains("whatsapp")) return phoneCall(call.group(1));

        // Volumen y sonido.
        if (containsAny(cmd,"sube el volumen","mas volumen","más volumen","ponlo mas fuerte","ponlo más fuerte","subele","súbele")) { adjustVolume(AudioManager.ADJUST_RAISE); return done("Subí el volumen"); }
        if (containsAny(cmd,"baja el volumen","menos volumen","ponlo mas bajo","ponlo más bajo","bajale","bájale")) { adjustVolume(AudioManager.ADJUST_LOWER); return done("Bajé el volumen"); }
        if (containsAny(cmd,"silencio","silencia","quita el sonido")) { ((AudioManager)context.getSystemService(Context.AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_MUTE,AudioManager.FLAG_SHOW_UI); return done("Silencié el audio"); }

        // Linterna, cámara y video.
        if (containsAny(cmd,"prende la linterna","enciende la linterna","activa la linterna")) return action(TorchHelper.set(context,true),"Encendí la linterna","No pude encender la linterna.");
        if (containsAny(cmd,"apaga la linterna","desactiva la linterna")) return action(TorchHelper.set(context,false),"Apagué la linterna","No pude apagar la linterna.");
        if (containsAny(cmd,"abre la camara y graba","abre la cámara y graba","graba video","graba vídeo")) { launch(new Intent(MediaStore.ACTION_VIDEO_CAPTURE)); return done("Abrí la cámara de video"); }
        if (containsAny(cmd,"abre la camara","abre cámara","abre la cámara","toma una foto")) { launch(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return done("Abrí la cámara"); }

        // Wi-Fi, Bluetooth y ajustes mediante interfaces permitidas por Android.
        if (containsAny(cmd,"abre wifi","abre wi fi","configura wifi","configura wi fi")) { launch(new Intent(Settings.ACTION_WIFI_SETTINGS)); return done("Abrí Wi‑Fi"); }
        if (containsAny(cmd,"abre bluetooth","configura bluetooth")) { launch(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return done("Abrí Bluetooth"); }
        if (containsAny(cmd,"abre configuracion","abre configuración","abre ajustes")) { launch(new Intent(Settings.ACTION_SETTINGS)); return done("Abrí Configuración"); }
        if (containsAny(cmd,"activa no molestar","modo no molestar","pon no molestar")) return setDnd(true);
        if (containsAny(cmd,"quita no molestar","desactiva no molestar")) return setDnd(false);

        // Alarmas.
        if (containsAny(cmd,"pon alarma","crea alarma","abre alarma")) {
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM); i.putExtra(AlarmClock.EXTRA_SKIP_UI,false); launch(i); return done("Abrí la alarma para que confirmes la hora");
        }

        // Archivos y documentos autorizados.
        Matcher folder = Pattern.compile("^crea (?:una )?carpeta (?:llamada )?(.+)$").matcher(cmd);
        if (folder.find()) return action(FileWorkspace.createFolder(context,folder.group(1)),"Creé la carpeta " + folder.group(1),"Primero elige una carpeta de archivos para Oti en la configuración.");
        Matcher find = Pattern.compile("^(?:busca|encuentra) (?:el archivo |el documento |la foto )?(.+)$").matcher(cmd);
        if (find.find() && FileWorkspace.tree(context) != null && !cmd.contains("google") && !cmd.contains("youtube") && !cmd.contains("internet")) {
            Uri u = FileWorkspace.findFirst(context,find.group(1));
            if (u != null) { FileWorkspace.saveLastDocument(context,u); FileWorkspace.open(context,u); return done("Encontré y abrí " + FileWorkspace.displayName(context,u)); }
            return say("No encontré ese archivo dentro de la carpeta que me autorizaste.");
        }
        if (containsAny(cmd,"elige un archivo","abre mis archivos","selecciona un archivo")) {
            Intent i = new Intent(context,FilePickerActivity.class); launch(i); return done("Abriendo el selector de archivos");
        }
        if (containsAny(cmd,"comparte el ultimo archivo por whatsapp","envia el ultimo archivo por whatsapp","envía el último archivo por whatsapp")) {
            return action(FileWorkspace.share(context,FileWorkspace.lastDocument(context),"com.whatsapp"),"Abrí WhatsApp para compartir el archivo","Primero selecciona un archivo.");
        }

        // Historial.
        if (containsAny(cmd,"que has hecho","qué has hecho","lee el historial","ultimo historial","último historial")) return say(HistoryManager.text(context,6));
        if (containsAny(cmd,"borra el historial","elimina el historial")) { launchSecurity("CLEAR_HISTORY","Borrar el historial de acciones de Oti"); return say("Te pediré huella o PIN antes de borrar el historial."); }

        // Búsquedas web / YouTube.
        if (containsAny(cmd,"busca","buscame","búscame","buscar","encuentra")) {
            String q = cmd.replaceFirst("^(busca|buscame|búscame|buscar|encuentra)\\s+","").trim();
            if (cmd.contains("youtube")) {
                q = q.replace("en youtube","").replace("youtube","").trim();
                return openUrl("https://www.youtube.com/results?search_query=" + enc(q),"Buscando en YouTube");
            }
            q = q.replace("en google","").replace("google","").replace("en internet","").trim();
            return openUrl("https://www.google.com/search?q=" + enc(q),"Buscando en Internet");
        }

        // Abrir apps por nombre.
        String app = detectApp(cmd); if (app != null && containsAny(cmd,"abre","pon","inicia","quiero")) return openApp(app);

        // Conversación general con IA en nube, si el dueño decidió configurarla.
        if (CloudAiClient.configured(context)) {
            String screen = a11y == null ? "" : a11y.describeScreen();
            CloudAiClient.ask(context,raw,screen,answer -> { speaker.speak(answer); HistoryManager.log(context,"Respuesta de IA en nube"); });
            return "Consultando la IA en la nube.";
        }
        return say("Entendí la frase, pero esa acción todavía no coincide con una función local. Puedes configurar la IA en la nube para preguntas más abiertas.");
    }

    private String sendWhatsApp(String who, String message) {
        String phone = ContactHelper.findPhone(context,who);
        if (phone == null) return say("No encontré el número de " + who + ". Autoriza Contactos o dime el número.");
        String digits = waNumber(phone);
        try {
            Uri u = Uri.parse("https://wa.me/" + digits + "?text=" + enc(message));
            Intent i = new Intent(Intent.ACTION_VIEW,u); i.setPackage("com.whatsapp"); launch(i);
            if (Prefs.autoActions(context) && OtiAccessibilityService.getInstance() != null) {
                UiAutomationQueue.begin(10000); UiAutomationQueue.add(1200,"Enviar","Send");
                HistoryManager.log(context,"Preparó envío automático de WhatsApp a " + who);
                return say("Abrí el chat de " + who + " y enviaré el mensaje cuando aparezca el botón Enviar.");
            }
            HistoryManager.log(context,"Preparó WhatsApp para " + who);
            return say("Abrí WhatsApp con el mensaje preparado para " + who + ".");
        } catch (Exception e) { return say("No pude abrir WhatsApp."); }
    }

    private String openWhatsAppChat(String who) {
        String phone = ContactHelper.findPhone(context,who); if (phone == null) return say("No encontré el número de " + who + ".");
        try { Intent i = new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/" + waNumber(phone))); i.setPackage("com.whatsapp"); launch(i); return done("Abrí WhatsApp con " + who); }
        catch (Exception e) { return say("No pude abrir ese chat."); }
    }

    private String whatsAppCall(String who, boolean video) {
        String phone = ContactHelper.findPhone(context,who); if (phone == null) return say("No encontré el número de " + who + ".");
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/" + waNumber(phone))); i.setPackage("com.whatsapp"); launch(i);
            if (OtiAccessibilityService.getInstance() != null) {
                UiAutomationQueue.begin(12000);
                if (video) UiAutomationQueue.add(1400,"Videollamada","Video call","Llamada de video");
                else UiAutomationQueue.add(1400,"Llamada de voz","Llamar","Voice call");
                if (Prefs.autoActions(context)) UiAutomationQueue.add(700,"Llamar","Call","Iniciar");
                HistoryManager.log(context,(video ? "Videollamada" : "Llamada") + " de WhatsApp solicitada a " + who);
                return say("Abrí el chat de " + who + " y buscaré el botón de " + (video ? "videollamada" : "llamada") + ".");
            }
            return say("Abrí el chat de " + who + ". Activa Accesibilidad para que Oti pueda tocar el botón de llamada.");
        } catch(Exception e) { return say("No pude abrir WhatsApp."); }
    }

    private String phoneCall(String who) {
        String phone = ContactHelper.findPhone(context,who); if (phone == null) return say("No encontré el número de " + who + ". Autoriza Contactos o dime el número.");
        try {
            launch(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:" + phone)));
            if (Prefs.autoActions(context) && OtiAccessibilityService.getInstance() != null) {
                UiAutomationQueue.begin(8000); UiAutomationQueue.add(900,"Llamar","Call");
                HistoryManager.log(context,"Llamada solicitada a " + who); return say("Abrí el número de " + who + " y confirmaré Llamar cuando aparezca.");
            }
            return done("Abrí el marcador con " + who);
        } catch(Exception e) { return say("No pude abrir el marcador."); }
    }

    private String setDnd(boolean on) {
        try {
            NotificationManager nm = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (!nm.isNotificationPolicyAccessGranted()) { launch(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); return say("Necesito que autorices No molestar. Ya abrí esa configuración."); }
            nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_PRIORITY : NotificationManager.INTERRUPTION_FILTER_ALL);
            return done(on ? "Activé No molestar" : "Desactivé No molestar");
        } catch(Exception e) { return say("No pude cambiar No molestar."); }
    }

    private String action(boolean ok, String successLog, String fail) { if (ok) return done(successLog); return say(fail); }
    private String done(String action) { HistoryManager.log(context,action); return say(action + "."); }
    private String say(String text) { speaker.speak(text); return text; }
    private void adjustVolume(int direction) { ((AudioManager)context.getSystemService(Context.AUDIO_SERVICE)).adjustStreamVolume(AudioManager.STREAM_MUSIC,direction,AudioManager.FLAG_SHOW_UI); }
    private void launch(Intent i) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i); }
    private void launchSecurity(String action,String description) { Intent i = new Intent(context,SecurityConfirmActivity.class); i.putExtra("action",action); i.putExtra("description",description); launch(i); }

    private String detectApp(String cmd) { for (String key : packages.keySet()) if (cmd.contains(key)) return key; return null; }
    private String openApp(String key) { String pkg = packages.get(key); Intent i = context.getPackageManager().getLaunchIntentForPackage(pkg); if (i == null) return say("No encontré " + key + " instalado."); launch(i); return done("Abrí " + key); }
    private String openUrl(String url,String spoken) { try { launch(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); return done(spoken); } catch(Exception e) { return say("No pude abrirlo."); } }
    private String waNumber(String p) { String d = p == null ? "" : p.replaceAll("[^0-9]",""); if (d.length() == 10) d = "52" + d; return d; }
    private static String stripWakeWord(String s) { return s.replaceFirst("^(oye\\s+|hey\\s+)?oti[,.!?:;\\s-]*","").trim(); }
    private static boolean containsAny(String s,String... xs) { for (String x:xs) if (s.contains(x)) return true; return false; }
    private static boolean equalsAny(String s,String... xs) { for (String x:xs) if (s.equals(x)) return true; return false; }
    private static String normalize(String s) { String n = Normalizer.normalize(s.toLowerCase(Locale.ROOT),Normalizer.Form.NFD).replaceAll("\\p{M}",""); return n.replaceAll("\\s+"," ").trim(); }
    private static String enc(String s) { try { return URLEncoder.encode(s,StandardCharsets.UTF_8.name()); } catch(Exception e) { return s; } }
}
