package com.azmovil.otiplus;

import android.content.Context;
import android.util.Base64;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class VoiceProfileManager {
    private static final String KEY = "voice_profile";
    private static final float THRESHOLD = 0.88f;
    private VoiceProfileManager() {}

    public static void save(Context c, float[] vector) {
        if (vector == null) return;
        ByteBuffer b = ByteBuffer.allocate(vector.length * 4).order(ByteOrder.LITTLE_ENDIAN);
        for (float v : vector) b.putFloat(v);
        Prefs.get(c).edit().putString(KEY, Base64.encodeToString(b.array(), Base64.NO_WRAP)).apply();
    }
    public static float[] load(Context c) {
        try {
            String s = Prefs.get(c).getString(KEY, null); if (s == null) return null;
            byte[] raw = Base64.decode(s, Base64.NO_WRAP);
            ByteBuffer b = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
            float[] out = new float[raw.length / 4];
            for (int i = 0; i < out.length; i++) out[i] = b.getFloat();
            return out;
        } catch (Exception e) { return null; }
    }
    public static boolean enrolled(Context c) { return load(c) != null; }
    public static void clear(Context c) { Prefs.get(c).edit().remove(KEY).putBoolean("voice_lock", false).apply(); }
    public static boolean verify(Context c, byte[] pcm) {
        float[] saved = load(c); float[] cur = VoiceFingerprint.extract(pcm);
        return saved != null && cur != null && VoiceFingerprint.similarity(saved, cur) >= THRESHOLD;
    }
}
